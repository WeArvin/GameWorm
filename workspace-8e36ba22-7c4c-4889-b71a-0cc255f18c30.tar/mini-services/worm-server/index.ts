/**
 * Worm Arena — authoritative multiplayer server (mini-service).
 *
 * Runs the SAME simulation code the client uses (config/worm/food/bot are
 * imported from src/game), ticking at 15 Hz. Clients send steering input
 * and render snapshots with local prediction + interpolation.
 *
 * MULTI-ROOM: one global public arena (code = null) plus private rooms
 * joined with a 4-char invite code — friends play together on their own
 * map. Each room is a fully independent simulation.
 *
 * Reach it through the Caddy gateway: socket.io path "/", XTransformPort=3003.
 */
import { createServer } from 'http';
import { Server } from 'socket.io';
import { CONFIG, SKINS } from '../../src/game/config';
import { FoodField } from '../../src/game/food';
import { computeBotSteering, findSafeSpawn } from '../../src/game/bot';
import { Worm } from '../../src/game/worm';
import { BOT_NAMES } from '../../src/game/i18n';
import { encodeFlags, type NetWormState } from '../../src/game/net';
import type { SegEntry } from '../../src/game/types';

const PORT = 3003;
const MAX_PLAYERS_PER_ROOM = 12;
const GLOBAL_BOTS = 10;
const PRIVATE_BOTS = 4; // private rooms stay light — friends provide the action
const TICK_MS = 66; // ~15 Hz
const MAX_PRIVATE_ROOMS = 60;
const ROOM_EMPTY_LIFETIME_MS = 90_000; // private room dies 90s after everyone leaves

const CELL = 120;
function cellKey(cx: number, cy: number): number {
  return cx * 4096 + cy;
}

const ROOM_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ROOM_CODE_RE = /^[A-Z0-9]{4}$/;

function makeRoomCode(): string {
  let s = '';
  for (let i = 0; i < 4; i++) {
    s += ROOM_ALPHABET[(Math.random() * ROOM_ALPHABET.length) | 0];
  }
  return s;
}

// ----------------------------------------------------------------------
// HTTP: tiny status endpoint (player count for the menu)
// Runs on its OWN port (3004) because socket.io owns every path on 3003.
// /count        → global arena alive count
// /count?room=X → private room alive count (0 when unknown)
// ----------------------------------------------------------------------
const countServer = createServer((req, res) => {
  if (req.url && req.url.startsWith('/count')) {
    const url = new URL(req.url, 'http://x');
    const roomParam = (url.searchParams.get('room') ?? '').toUpperCase();
    let n = 0;
    if (ROOM_CODE_RE.test(roomParam)) {
      const room = privateRooms.get(roomParam);
      if (room) for (const rec of room.players.values()) if (rec.worm.alive) n++;
    } else if (roomParam) {
      // Invalid code: report 0 (do NOT leak the global count).
      n = 0;
    } else {
      for (const rec of globalRoom.players.values()) if (rec.worm.alive) n++;
    }
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'no-store',
    });
    res.end(JSON.stringify({ count: n }));
    return;
  }
  res.writeHead(404);
  res.end();
});

const httpServer = createServer();

const io = new Server(httpServer, {
  // DO NOT change the path — Caddy forwards "/" to this port via XTransformPort.
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

interface PlayerRec {
  worm: Worm;
  input: { targetAngle: number; boosting: boolean };
}

// ----------------------------------------------------------------------
// Room — one independent authoritative simulation
// ----------------------------------------------------------------------
class Room {
  readonly key: string;
  readonly code: string | null; // null = global arena
  readonly botCount: number;
  readonly createdAt = Date.now();

  worms: Worm[] = [];
  food = new FoodField(CONFIG.world.w, CONFIG.world.h);
  segGrid = new Map<number, SegEntry[]>();
  doomed = new Set<number>();
  botRespawns: number[] = [];
  players = new Map<string, PlayerRec>(); // socketId → rec

  private nextId = 1;
  private time = 0;
  private powerupTimer = 0;
  private foodQuery: number[] = [];
  private lastFoodId: number;
  emptySince = Date.now();

  constructor(code: string | null) {
    this.code = code;
    this.key = code === null ? 'global' : `room:${code}`;
    this.botCount = code === null ? GLOBAL_BOTS : PRIVATE_BOTS;
    this.food.init(CONFIG.food.targetCount);
    this.lastFoodId = this.food.lastId;
    for (let i = 0; i < this.botCount; i++) this.spawnBot();
  }

  get playerCount(): number {
    return this.players.size;
  }

  spawnBot(): void {
    const base = BOT_NAMES.en[(Math.random() * BOT_NAMES.en.length) | 0];
    const name = Math.random() < 0.4 ? `${base}${10 + ((Math.random() * 89) | 0)}` : base;
    const bot = new Worm(this.nextId++, name, SKINS[(Math.random() * SKINS.length) | 0], false);
    bot.skill = Math.random() < CONFIG.bots.dumbRatio ? 0 : 1;
    const pos = { x: 0, y: 0 };
    findSafeSpawn(this.worms, this.segGrid, pos);
    bot.reset(pos.x, pos.y, Math.random() * Math.PI * 2, CONFIG.worm.startScore + Math.random() * 60);
    this.worms.push(bot);
  }

  addPlayer(socketId: string, name: string, skinIdx: number): Worm {
    const worm = new Worm(this.nextId++, name, SKINS[skinIdx % SKINS.length], true);
    const pos = { x: 0, y: 0 };
    findSafeSpawn(this.worms, this.segGrid, pos);
    worm.reset(pos.x, pos.y, Math.random() * Math.PI * 2, CONFIG.worm.startScore);
    this.worms.push(worm);
    this.players.set(socketId, { worm, input: { targetAngle: worm.angle, boosting: false } });
    this.emptySince = Date.now();
    return worm;
  }

  removePlayer(socketId: string): PlayerRec | null {
    const rec = this.players.get(socketId);
    if (!rec) return null;
    this.players.delete(socketId);
    const i = this.worms.indexOf(rec.worm);
    if (i >= 0) this.worms.splice(i, 1);
    if (this.players.size === 0) this.emptySince = Date.now();
    return rec;
  }

  respawnPlayer(socketId: string): Worm | null {
    const rec = this.players.get(socketId);
    if (!rec || rec.worm.alive) return null;
    const pos = { x: 0, y: 0 };
    findSafeSpawn(this.worms, this.segGrid, pos);
    rec.worm.reset(pos.x, pos.y, Math.random() * Math.PI * 2, CONFIG.worm.startScore);
    this.worms.push(rec.worm);
    rec.input.targetAngle = rec.worm.angle;
    rec.input.boosting = false;
    return rec.worm;
  }

  wormState(w: Worm): NetWormState {
    let skinIdx = SKINS.findIndex((s) => s.base === w.skin.base);
    if (skinIdx < 0) skinIdx = 0;
    return [
      w.id,
      Math.round(w.x),
      Math.round(w.y),
      Math.round(w.angle * 100) / 100,
      Math.round(w.score),
      encodeFlags(w),
      w.name,
      skinIdx,
    ];
  }

  buildSegGrid(): void {
    this.segGrid.clear();
    for (let wi = 0; wi < this.worms.length; wi++) {
      const w = this.worms[wi];
      if (!w.alive) continue;
      const n = w.segX.length;
      const step = n > 60 ? 2 : 1;
      for (let s = 0; s < n; s += step) {
        const key = cellKey(Math.floor(w.segX[s] / CELL), Math.floor(w.segY[s] / CELL));
        const bucket = this.segGrid.get(key);
        if (bucket) bucket.push({ wi, s });
        else this.segGrid.set(key, [{ wi, s }]);
      }
      if (step !== 1) {
        const key = cellKey(Math.floor(w.x / CELL), Math.floor(w.y / CELL));
        const bucket = this.segGrid.get(key);
        if (bucket) bucket.push({ wi, s: 0 });
        else this.segGrid.set(key, [{ wi, s: 0 }]);
      }
    }
  }

  killWorm(w: Worm, deaths: Array<{ id: number; name: string; score: number }>): void {
    w.alive = false;
    // Drop food along the body.
    const pts: Array<{ x: number; y: number }> = [];
    for (let s = 0; s < w.segX.length; s += 2) pts.push({ x: w.segX[s], y: w.segY[s] });
    this.food.scatter(pts, 2, w.skin.base);
    deaths.push({ id: w.id, name: w.name, score: Math.floor(w.score) });
    const i = this.worms.indexOf(w);
    if (i >= 0) this.worms.splice(i, 1);
    if (!w.isPlayer) this.botRespawns.push(CONFIG.bots.respawnDelay);
  }

  checkDeaths(deaths: Array<{ id: number; name: string; score: number }>): void {
    this.doomed.clear();
    const W = CONFIG.world.w;
    const H = CONFIG.world.h;
    const HF = CONFIG.worm.hitFactor;

    for (let wi = 0; wi < this.worms.length; wi++) {
      const w = this.worms[wi];
      if (!w.alive) continue;
      if (w.ghostT > 0) continue; // ghost worms are untouchable

      if (w.x < 0 || w.y < 0 || w.x > W || w.y > H) {
        this.doomed.add(wi);
        continue;
      }

      const r = w.radius;
      const c0x = Math.floor((w.x - r - 30) / CELL);
      const c1x = Math.floor((w.x + r + 30) / CELL);
      const c0y = Math.floor((w.y - r - 30) / CELL);
      const c1y = Math.floor((w.y + r + 30) / CELL);

      outer: for (let cx = c0x; cx <= c1x; cx++) {
        for (let cy = c0y; cy <= c1y; cy++) {
          const bucket = this.segGrid.get(cellKey(cx, cy));
          if (!bucket) continue;
          for (const e of bucket) {
            if (e.wi === wi) continue;
            const other = this.worms[e.wi];
            if (!other || !other.alive) continue;
            if (other.ghostT > 0) continue; // ghost bodies are harmless
            const dx = other.segX[e.s] - w.x;
            const dy = other.segY[e.s] - w.y;
            const rr = (r + other.radius) * HF;
            if (dx * dx + dy * dy < rr * rr) {
              if (e.s === 0) {
                if (w.score > other.score) {
                  const oi = this.worms.indexOf(other);
                  if (oi >= 0) this.doomed.add(oi);
                } else if (other.score > w.score) {
                  this.doomed.add(wi);
                } else {
                  this.doomed.add(wi);
                  const oi = this.worms.indexOf(other);
                  if (oi >= 0) this.doomed.add(oi);
                }
              } else {
                this.doomed.add(wi);
              }
              if (this.doomed.has(wi)) break outer;
            }
          }
        }
      }
    }

    if (this.doomed.size === 0) return;
    // Kill from the highest index down so splices keep lower indices valid.
    const idxs = [...this.doomed].sort((a, b) => b - a);
    for (const wi of idxs) {
      const w = this.worms[wi];
      if (w && w.alive) this.killWorm(w, deaths);
    }
  }

  consumeFood(
    w: Worm,
    it: { kind: string; value: number; x: number; y: number },
  ): void {
    const mult = w.x2T > 0 ? 2 : 1;
    w.score += it.value * mult;

    switch (it.kind) {
      case 'magnet':
        w.magnetT = CONFIG.powerup.magnetDur;
        break;
      case 'x2':
        w.x2T = CONFIG.powerup.x2Dur;
        break;
      case 'ghost':
        w.ghostT = CONFIG.powerup.ghostDur;
        break;
      case 'freeze': {
        const R = CONFIG.powerup.freezeRadius;
        for (const o of this.worms) {
          if (o === w || !o.alive) continue;
          if (Math.hypot(o.x - w.x, o.y - w.y) < R) o.frozenT = CONFIG.powerup.freezeDur;
        }
        break;
      }
      default:
        break;
    }
  }

  updateFoodEating(eaten: Array<[number, number, number]>): void {
    const toRemove: number[] = [];
    const magnetR = CONFIG.food.magnetSpeed;

    for (const w of this.worms) {
      if (!w.alive) continue;
      const r = w.radius;
      const magnet = w.magnetT > 0 ? CONFIG.powerup.magnetDist : CONFIG.food.magnetDist;
      this.food.query(w.x, w.y, magnet, this.foodQuery);
      for (const i of this.foodQuery) {
        const it = this.food.items[i];
        if (!it) continue;
        const dx = w.x - it.x;
        const dy = w.y - it.y;
        const d = Math.hypot(dx, dy);
        if (d < r + it.r + 3) {
          this.consumeFood(w, it);
          toRemove.push(i);
          eaten.push([it.id, Math.round(it.x), Math.round(it.y)]);
        } else if (d < magnet + r) {
          const s = (magnetR * 0.016) / Math.max(d, 1);
          it.x += dx * s;
          it.y += dy * s;
        }
      }
    }

    this.food.removeIndices(toRemove);
  }

  worldUpdate(dt: number, deaths: Array<{ id: number; name: string; score: number }>, eaten: Array<[number, number, number]>): void {
    this.buildSegGrid();

    // Bots.
    for (let bi = 0; bi < this.worms.length; bi++) {
      const w = this.worms[bi];
      if (w.isPlayer || !w.alive) continue;
      const steer = computeBotSteering(w, bi, this.worms, this.segGrid, this.food, this.time);
      w.update(dt, steer);
    }

    // Players steer from network input.
    for (const rec of this.players.values()) {
      if (!rec.worm.alive) continue;
      rec.worm.update(dt, rec.input);
    }

    this.checkDeaths(deaths);
    this.food.update(dt);
    this.updateFoodEating(eaten);

    this.food.topUp(CONFIG.food.targetCount);
    this.powerupTimer += dt;
    if (this.powerupTimer >= CONFIG.powerup.spawnEvery) {
      this.powerupTimer = 0;
      if (this.food.countPowerups() < CONFIG.powerup.maxOnMap) this.food.spawnPowerup();
    }
    for (let i = this.botRespawns.length - 1; i >= 0; i--) {
      this.botRespawns[i] -= dt;
      if (this.botRespawns[i] <= 0) {
        this.botRespawns.splice(i, 1);
        this.spawnBot();
      }
    }
  }

  /** One 15 Hz simulation + broadcast step. */
  tick(): void {
    const dt = TICK_MS / 1000;
    this.time += dt;
    const deaths: Array<{ id: number; name: string; score: number }> = [];
    const eaten: Array<[number, number, number]> = [];
    const prevFoodId = this.lastFoodId;

    this.worldUpdate(dt, deaths, eaten);
    this.lastFoodId = this.food.lastId;

    const added = this.food.itemsSince(prevFoodId);
    const states = this.worms.filter((w) => w.alive).map((w) => this.wormState(w));

    io.to(this.key).emit('ps', { w: states, e: eaten });
    if (added.length) io.to(this.key).emit('fa', this.food.toNet(added));
    for (const d of deaths) io.to(this.key).emit('died', d);
  }
}

// ----------------------------------------------------------------------
// Room registry
// ----------------------------------------------------------------------

const globalRoom = new Room(null);
const privateRooms = new Map<string, Room>();
const socketRoom = new Map<string, Room>(); // socketId → room

function getOrCreatePrivateRoom(code: string): Room | null {
  const existing = privateRooms.get(code);
  if (existing) return existing;
  if (privateRooms.size >= MAX_PRIVATE_ROOMS) return null;
  const room = new Room(code);
  privateRooms.set(code, room);
  console.log(`[worm-server] private room ${code} created`);
  return room;
}

// ----------------------------------------------------------------------
// Socket handlers
// ----------------------------------------------------------------------

io.on('connection', (socket) => {
  socket.on('join', (data: { name?: string; skin?: number; room?: string }) => {
    // Room selection: 4-char invite code joins (or creates) a private room.
    const wanted = String(data?.room ?? '').toUpperCase();
    if (wanted && !ROOM_CODE_RE.test(wanted)) {
      // A code was given but it is malformed — reject instead of silently
      // dumping the player into the global arena.
      socket.emit('badRoom', { room: wanted });
      return;
    }
    let room: Room;
    if (ROOM_CODE_RE.test(wanted)) {
      const existing = privateRooms.get(wanted);
      if (existing) {
        room = existing;
      } else {
        const created = getOrCreatePrivateRoom(wanted);
        if (!created) {
          socket.emit('full');
          return;
        }
        room = created;
      }
    } else {
      room = globalRoom;
    }

    if (room.playerCount >= MAX_PLAYERS_PER_ROOM) {
      socket.emit('full');
      return;
    }

    const name = String(data?.name ?? '').slice(0, 12) || 'Worm';
    const skinIdx = Math.abs(Number(data?.skin ?? 0) | 0);
    const worm = room.addPlayer(socket.id, name, skinIdx);
    socketRoom.set(socket.id, room);
    socket.join(room.key);

    socket.emit('welcome', {
      id: worm.id,
      room: room.code,
      worms: room.worms.filter((w) => w.alive).map((w) => room.wormState(w)),
      food: room.food.toNet(room.food.items),
    });
    console.log(
      `[worm-server] ${name} joined ${room.code === null ? 'global arena' : `room ${room.code}`} (${room.playerCount} in room)`,
    );
  });

  socket.on('st', (d: { a?: number; b?: number }) => {
    const room = socketRoom.get(socket.id);
    const rec = room?.players.get(socket.id);
    if (!rec || !rec.worm.alive) return;
    if (typeof d?.a === 'number' && isFinite(d.a)) rec.input.targetAngle = d.a;
    rec.input.boosting = !!d?.b;
  });

  socket.on('respawn', () => {
    const room = socketRoom.get(socket.id);
    if (!room) return;
    const worm = room.respawnPlayer(socket.id);
    if (!worm) return;
    socket.emit('respawned', { st: room.wormState(worm) });
    console.log(`[worm-server] ${worm.name} respawned`);
  });

  socket.on('disconnect', () => {
    const room = socketRoom.get(socket.id);
    if (!room) return;
    const rec = room.removePlayer(socket.id);
    socketRoom.delete(socket.id);
    if (rec) {
      console.log(
        `[worm-server] ${rec.worm.name} left ${room.code === null ? 'global arena' : `room ${room.code}`} (${room.playerCount} in room)`,
      );
    }
  });

  socket.on('error', (err: unknown) => {
    console.error(`[worm-server] socket error (${socket.id}):`, err);
  });
});

// ----------------------------------------------------------------------
// Main loop — tick every room, GC stale private rooms
// ----------------------------------------------------------------------

let gcCounter = 0;

setInterval(() => {
  try {
    globalRoom.tick();
    for (const room of privateRooms.values()) {
      if (room.playerCount === 0) continue; // idle private room: pause the sim
      room.tick();
    }

    // GC every ~5 s: private rooms empty for too long are destroyed.
    if (++gcCounter % 75 === 0) {
      const now = Date.now();
      for (const [code, room] of privateRooms) {
        if (room.playerCount === 0 && now - room.emptySince > ROOM_EMPTY_LIFETIME_MS) {
          privateRooms.delete(code);
          console.log(`[worm-server] private room ${code} closed (empty)`);
        }
      }
    }
  } catch (err) {
    // One bad frame must never kill the broadcast loop.
    console.error('[worm-server] tick error:', err);
  }
}, TICK_MS);

httpServer.listen(PORT, () => {
  console.log(`[worm-server] socket.io listening on port ${PORT}`);
});

countServer.listen(PORT + 1, () => {
  console.log(`[worm-server] count endpoint listening on port ${PORT + 1}`);
});

process.on('SIGTERM', () => {
  httpServer.close(() => process.exit(0));
});
process.on('SIGINT', () => {
  httpServer.close(() => process.exit(0));
});
