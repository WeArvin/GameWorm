/**
 * Fake multiplayer client for testing the Worm Arena online server.
 * Joins as a player, steers in circles, boosts sometimes, respawns if dead.
 *
 * Usage: bun /home/z/my-project/scripts/fake-player.mts [name] [durationSec] [roomCode]
 */
import { io, type Socket } from 'socket.io-client';

const name = process.argv[2] ?? 'TestBot';
const durationSec = Number(process.argv[3] ?? 60);
const room = (process.argv[4] ?? '').trim().toUpperCase();

const socket: Socket = io('http://localhost:3003', {
  path: '/',
  transports: ['websocket', 'polling'],
  forceNew: true,
});

let myId = -1;
let alive = false;
let t = 0;
const skin = Math.floor(Math.random() * 8);

setInterval(() => {
  t += 0.08;
  if (!alive) return;
  // Gentle circle + occasional boost.
  const a = t * 0.9;
  const boosting = Math.sin(t * 0.35) > 0.75;
  socket.emit('st', { a, b: boosting ? 1 : 0 });
}, 80);

socket.on('connect', () => {
  console.log(`[fake] connected: ${socket.id}${room ? ` (room ${room})` : ' (global)'}`);
  socket.emit('join', { name, skin, room: room || undefined });
});

socket.on('welcome', (d: { id: number; room: string | null; worms: unknown[] }) => {
  myId = d.id;
  alive = true;
  console.log(
    `[fake] joined as worm #${myId} in ${d.room === null ? 'global arena' : `room ${d.room}`}, ${d.worms.length} worms in world`,
  );
});

socket.on('died', (d: { id: number; name: string; score: number }) => {
  if (d.id === myId) {
    alive = false;
    console.log(`[fake] died with score ${d.score}, respawning in 2s...`);
    setTimeout(() => socket.emit('respawn'), 2000);
  }
});

socket.on('respawned', () => {
  alive = true;
  console.log('[fake] respawned');
});

socket.on('full', () => {
  console.log('[fake] server full');
  process.exit(1);
});

socket.on('disconnect', () => {
  console.log('[fake] disconnected');
  process.exit(0);
});

setTimeout(() => {
  console.log(`[fake] done (${durationSec}s)`);
  socket.disconnect();
  process.exit(0);
}, durationSec * 1000);
