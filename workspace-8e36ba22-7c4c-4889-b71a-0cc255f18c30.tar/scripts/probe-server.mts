/** Probe: join the worm server and count 'ps' snapshot events for 4s. */
import { io, type Socket } from 'socket.io-client';

const socket: Socket = io('http://localhost:3003', { path: '/', forceNew: true });
let psCount = 0;
let lastSizes: number[] = [];

socket.on('connect', () => {
  socket.emit('join', { name: 'ProbeX', skin: 3 });
});

socket.on('welcome', (d: { worms: Array<unknown> }) => {
  console.log(`[probe] welcome, ${d.worms.length} worms`);
});

socket.on('ps', (d: { w: Array<Array<number | string>>; e: Array<unknown> }) => {
  psCount++;
  if (lastSizes.length < 3) lastSizes.push(d.w.length);
  if (psCount === 3) {
    const me = d.w.find((w) => w[6] === 'ProbeX');
    console.log(`[probe] ps#3: worms=${d.w.length} sample=${JSON.stringify(d.w[0])} me=${JSON.stringify(me)}`);
  }
});

setTimeout(() => {
  console.log(`[probe] total ps events in 4s: ${psCount} (worm counts: ${lastSizes.join(',')})`);
  socket.disconnect();
  process.exit(0);
}, 4000);
