#!/usr/bin/env bash
# Full production-composition E2E for Worm Arena, without touching the dev
# server or the platform Caddy.
#
# Topology (mirrors deploy/Caddyfile.prod):
#   my caddy :82 ── default ──────────► prod Next standalone :3100
#              ├─ ?XTransformPort=3003 ► worm-server :3003
#              └─ ?XTransformPort=3004 ► worm-server :3004
set -u
cd /home/z/my-project
mkdir -p .zscripts

cleanup() {
  [ -n "${CPID:-}" ] && kill "$CPID" 2>/dev/null
  [ -n "${PPID_:-}" ] && kill "$PPID_" 2>/dev/null
  agent-browser close > /dev/null 2>&1
}
trap cleanup EXIT

# --- 0) worm-server up? ----------------------------------------------------
(exec 3<>/dev/tcp/127.0.0.1/3003) 2>/dev/null && echo "[e2e] worm-server: UP" || { echo "[e2e] worm-server DOWN"; exit 1; }

# --- 1) production standalone server on :3100 ------------------------------
nohup env PORT=3100 HOSTNAME=127.0.0.1 NODE_ENV=production bun .next/standalone/server.js > /tmp/prod-e2e.log 2>&1 &
PPID_=$!
sleep 3.5
echo "[e2e] prod home: $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:3100/)"

# --- 2) user-level caddy on :82 (prod routing shape) ------------------------
cat > /home/z/my-project/scripts/Caddyfile.e2e <<'EOF'
:3200 {
        @p3003 query XTransformPort=3003
        handle @p3003 {
                reverse_proxy localhost:3003
        }
        @p3004 query XTransformPort=3004
        handle @p3004 {
                reverse_proxy localhost:3004
        }
        handle {
                reverse_proxy localhost:3100
        }
}
EOF
nohup caddy run --config /home/z/my-project/scripts/Caddyfile.e2e --adapter caddyfile > /tmp/caddy-e2e.log 2>&1 &
CPID=$!
sleep 1.5
echo "[e2e] caddy home: $(curl -s -o /dev/null -w '%{http_code}' 'http://localhost:3200/?XTransformPort=3100')"
echo "[e2e] caddy ws:   $(curl -s 'http://localhost:3200/socket.io/?XTransformPort=3003&EIO=4&transport=polling' | head -c 60)"

# --- 3) browser E2E ---------------------------------------------------------
agent-browser set viewport 1280 720 > /dev/null
agent-browser open "http://localhost:3200/?XTransformPort=3100" > /dev/null
agent-browser wait --load networkidle > /dev/null 2>&1
agent-browser wait 2000 > /dev/null
agent-browser screenshot /home/z/my-project/.zscripts/prod_menu_styled.png > /dev/null
echo "[e2e] page errors at menu: $(agent-browser errors 2>/dev/null | head -3)"

agent-browser snapshot -i > /tmp/e2e_snap1.txt
ONLINE_REF=$(grep 'آنلاین' /tmp/e2e_snap1.txt | grep -o 'ref=e[0-9]*' | head -1 | cut -d= -f2)
echo "[e2e] online tab ref: ${ONLINE_REF:-NOT FOUND}"
[ -z "$ONLINE_REF" ] && exit 1
agent-browser click "@$ONLINE_REF" > /dev/null
agent-browser wait 800 > /dev/null

agent-browser snapshot -i > /tmp/e2e_snap2.txt
PLAY_REF=$(grep -o 'ref=e[0-9]*' /tmp/e2e_snap2.txt > /dev/null; grep -E 'ورود به بازی آنلاین|شروع بازی' /tmp/e2e_snap2.txt | grep -o 'ref=e[0-9]*' | head -1 | cut -d= -f2)
echo "[e2e] play button ref: ${PLAY_REF:-NOT FOUND}"
[ -z "$PLAY_REF" ] && exit 1
agent-browser click "@$PLAY_REF" > /dev/null
agent-browser wait 6000 > /dev/null

agent-browser screenshot /home/z/my-project/.zscripts/prod_online_hud.png > /dev/null
agent-browser snapshot -c > /tmp/e2e_snap3.txt
echo "[e2e] HUD evidence:"
grep -E "امتیاز|رتبه|بردها|بوست|بازیکن واقعی|نفر آنلاین" /tmp/e2e_snap3.txt | head -6
echo "[e2e] page errors after online join: $(agent-browser errors 2>/dev/null | head -3)"
echo "[e2e] DONE"
