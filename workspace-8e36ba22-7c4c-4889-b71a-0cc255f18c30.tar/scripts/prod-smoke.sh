#!/usr/bin/env bash
# Production-build smoke test for Worm Arena.
# Boots the standalone Next.js server on :3100 (worm-server on :3003/3004),
# hits it through the Caddy gateway (:81) like a real client would, then runs
# a browser E2E pass. Everything happens inside ONE call because background
# shells are reaped between tool calls in this sandbox.
set -u
cd /home/z/my-project

PORT=3100
LOG=/tmp/prod-smoke.log

# --- 0) make sure the multiplayer worm-server is up -----------------------
if ! (exec 3<>/dev/tcp/127.0.0.1/3003) 2>/dev/null; then
  echo "[smoke] worm-server not running -> starting it"
  (cd mini-services/worm-server && nohup bun run dev > /tmp/worm-smoke.log 2>&1 &)
  sleep 2.5
fi
(exec 3<>/dev/tcp/127.0.0.1/3003) 2>/dev/null && echo "[smoke] worm-server: UP" || echo "[smoke] worm-server: DOWN (arm-net will try to fix)"

# --- 1) boot the production standalone server on :3100 --------------------
nohup env PORT=$PORT HOSTNAME=127.0.0.1 NODE_ENV=production bun .next/standalone/server.js > "$LOG" 2>&1 &
PID=$!
sleep 4

echo "[smoke] home status: $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/)"
echo "[smoke] arm-net:     $(curl -s http://127.0.0.1:$PORT/api/arm-net)"
echo "[smoke] ws handshake: $(curl -s "http://localhost:81/socket.io/?XTransformPort=3003&EIO=4&transport=polling" | head -c 120)"
echo "[smoke] counter:     $(curl -s "http://localhost:81/count?XTransformPort=3004")"
echo "[smoke] client bundle has gateway URL: $(grep -rl 'XTransformPort' .next/standalone/.next/static/chunks 2>/dev/null | head -1 || echo 'NOT FOUND')"

# --- 2) browser E2E against the PRODUCTION build --------------------------
B=http://localhost:81/?XTransformPort=$PORT
agent-browser set viewport 1280 720 > /dev/null
agent-browser open "$B" > /dev/null
agent-browser wait --load networkidle > /dev/null 2>&1
agent-browser wait 1500 > /dev/null
echo "[smoke] title: $(agent-browser get title)"
agent-browser screenshot /home/z/my-project/.zscripts/prod_menu.png > /dev/null
echo "[smoke] page errors after menu:"
agent-browser errors || true

# join the ONLINE arena through the production build
agent-browser snapshot -i > /tmp/prod_snapshot.txt
ONLINE_REF=$(grep -o '@e[0-9]*' /tmp/prod_snapshot.txt | head -40 | while read r; do :; done; grep -n "ورود به بازی آنلاین" /tmp/prod_snapshot.txt | head -1 | sed 's/.*\(@e[0-9]*\).*/\1/')
echo "[smoke] online button ref: ${ONLINE_REF:-NOT FOUND}"
if [ -n "${ONLINE_REF:-}" ]; then
  agent-browser click "$ONLINE_REF" > /dev/null
  agent-browser wait 4000 > /dev/null
  agent-browser screenshot /home/z/my-project/.zscripts/prod_online.png > /dev/null
  echo "[smoke] page errors after online join:"
  agent-browser errors || true
  echo "[smoke] online HUD text sample:"
  agent-browser snapshot -c > /tmp/prod_online.txt
  grep -E "امتیاز|رتبه|بردها|اتاق" /tmp/prod_online.txt | head -5
fi

agent-browser close > /dev/null 2>&1
kill $PID 2>/dev/null
echo "[smoke] DONE (prod server on :$PORT stopped, worm-server left running)"
