import { NextResponse } from 'next/server';
import { spawn } from 'child_process';
import { existsSync, openSync } from 'fs';
import path from 'path';
import net from 'net';

export const dynamic = 'force-dynamic';

/** Is something listening on this port? */
function probe(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const s = net.connect(port, '127.0.0.1');
    s.once('connect', () => {
      s.end();
      resolve(true);
    });
    s.once('error', () => resolve(false));
    s.setTimeout(800, () => {
      s.destroy();
      resolve(false);
    });
  });
}

/**
 * Ensures the worm-server (mini-service) is running. The sandbox reaps
 * background shells, so we spawn it as a child of the long-lived Next.js
 * server process. Safe to call repeatedly (checks the port first).
 */
export async function GET() {
  const up = await probe(3003);
  if (up) {
    return NextResponse.json({ status: 'running' });
  }

  const cwd = path.join(process.cwd(), 'mini-services', 'worm-server');
  if (!existsSync(path.join(cwd, 'index.ts'))) {
    return NextResponse.json({ status: 'missing' }, { status: 500 });
  }

  const out = openSync(path.join(process.cwd(), 'worm-server.log'), 'a');
  // Production runs without --hot (plain `bun index.ts`).
  const script = process.env.NODE_ENV === 'production' ? 'start' : 'dev';
  const child = spawn('bun', ['run', script], {
    cwd,
    stdio: ['ignore', out, out],
  });
  child.on('error', (e) => console.error('[arm-net] spawn error:', e));

  // Give it a moment, then report.
  await new Promise((r) => setTimeout(r, 1500));
  const nowUp = await probe(3003);
  return NextResponse.json({ status: nowUp ? 'started' : 'failed' });
}
