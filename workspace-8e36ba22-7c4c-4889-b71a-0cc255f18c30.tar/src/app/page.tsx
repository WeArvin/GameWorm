import WormGame from "@/components/game/WormGame";

export default function Home() {
  return <WormGame />;
}
