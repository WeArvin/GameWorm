'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Copy, Ghost, Gem, Home, Magnet, RotateCw, Snowflake, Users } from 'lucide-react';
import type { ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SKINS } from '@/game/config';
import { Game } from '@/game/engine';
import { t } from '@/game/i18n';
import { loadSave, saveSave } from '@/game/storage';
import type { Effects, Lang, Stats } from '@/game/types';

type Phase = 'menu' | 'play' | 'dead';
type MenuMode = 'single' | 'online';
type NetStatus = 'idle' | 'connecting' | 'connected' | 'error' | 'closed' | 'full' | 'badCode';
type NetError = 'connLost' | 'serverFull' | 'badCode' | null;

/** Robust touch detection: pointer + touch APIs + UA fallback. */
function detectTouch(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(pointer: coarse)').matches ||
    navigator.maxTouchPoints > 0 ||
    'ontouchstart' in window ||
    /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)
  );
}

// Unambiguous alphabet for 4-char invite codes (no 0/O/1/I).
const ROOM_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ROOM_CODE_RE = /^[A-Z0-9]{4}$/;

function makeRoomCode(): string {
  let s = '';
  for (let i = 0; i < 4; i++) {
    s += ROOM_ALPHABET[(Math.random() * ROOM_ALPHABET.length) | 0];
  }
  return s;
}

export default function WormGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const bestRef = useRef(0);
  const menuModeRef = useRef<MenuMode>('single');

  const [phase, setPhase] = useState<Phase>('menu');
  const [lang, setLang] = useState<Lang>('fa');
  const [name, setName] = useState('');
  const [skinIdx, setSkinIdx] = useState(0);
  const [best, setBest] = useState(0);
  const [stats, setStats] = useState<Stats | null>(null);
  const [finalScore, setFinalScore] = useState(0);
  const [newRecord, setNewRecord] = useState(false);
  const [isTouch, setIsTouch] = useState(false);
  const [isPortrait, setIsPortrait] = useState(false);
  const [hintVisible, setHintVisible] = useState(true);
  const [menuMode, setMenuMode] = useState<MenuMode>('single');
  const [netStatus, setNetStatus] = useState<NetStatus>('idle');
  const [netError, setNetError] = useState<NetError>(null);
  const [onlineCount, setOnlineCount] = useState<number | null>(null);
  // Private rooms: typed code in the menu + the room we are playing in.
  const [joinCode, setJoinCode] = useState('');
  const [roomCode, setRoomCode] = useState<string | null>(null);
  const [invitedCode, setInvitedCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const tr = t(lang);
  const dir = lang === 'fa' ? 'rtl' : 'ltr';

  // -------------------------------------------------------------- mount
  useEffect(() => {
    const save = loadSave();

    const canvas = canvasRef.current;
    if (!canvas) return;

    const handleDeath = (score: number) => {
      const record = score > bestRef.current;
      const nb = Math.max(bestRef.current, score);
      bestRef.current = nb;
      setBest(nb);
      setNewRecord(record);
      setFinalScore(score);
      saveSave({ ...loadSave(), best: nb });
      setPhase('dead');
    };

    const handleNetStatus = (s: NetStatus) => {
      setNetStatus(s);
      if (s === 'connecting' || s === 'connected') {
        setNetError(null);
      } else if (s === 'full') {
        setNetError('serverFull');
        setRoomCode(null);
        setPhase('menu');
      } else if (s === 'badCode') {
        setNetError('badCode');
        setRoomCode(null);
        setPhase('menu');
      } else if (s === 'closed' || s === 'error') {
        // Engine already rebuilt the local world; drop the player to the menu.
        setRoomCode(null);
        setNetError((prev) => prev ?? 'connLost');
        setPhase((p) => (p === 'menu' ? p : 'menu'));
      }
    };

    const game = new Game(canvas, {
      onStats: setStats,
      onDeath: handleDeath,
      onNetStatus: handleNetStatus,
    });
    gameRef.current = game;

    const ro = new ResizeObserver(() => game.resize());
    ro.observe(canvas);

    // Hydrate client-only saved prefs after mount (one frame later to keep
    // the effect body free of cascading setState).
    const raf = requestAnimationFrame(() => {
      setLang(save.lang);
      setName(save.name);
      setSkinIdx(save.skinIdx);
      setBest(save.best);
      bestRef.current = save.best;
      setIsTouch(detectTouch());
      // Invite link support: /?room=CODE pre-fills the private-room join.
      const param = new URLSearchParams(window.location.search).get('room') ?? '';
      const code = param.trim().toUpperCase();
      if (ROOM_CODE_RE.test(code)) {
        setInvitedCode(code);
        setJoinCode(code);
        setMenuMode('online');
        menuModeRef.current = 'online';
      }
    });

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      game.destroy();
      gameRef.current = null;
    };
  }, []);

  // Track device orientation (for the landscape prompt on touch devices).
  useEffect(() => {
    const mq = window.matchMedia('(orientation: portrait)');
    const onChange = () => setIsPortrait(mq.matches);
    const raf = requestAnimationFrame(onChange);
    mq.addEventListener('change', onChange);
    return () => {
      cancelAnimationFrame(raf);
      mq.removeEventListener('change', onChange);
    };
  }, []);

  // Freeze the world while the rotate-phone overlay is visible.
  useEffect(() => {
    gameRef.current?.setPaused(phase === 'play' && isTouch && isPortrait);
  }, [phase, isTouch, isPortrait]);

  // Hint auto-hide each run.
  useEffect(() => {
    if (phase !== 'play') return;
    const timer = setTimeout(() => setHintVisible(false), 6000);
    return () => clearTimeout(timer);
  }, [phase]);

  // Poll the online player count while the menu + online tab are open.
  useEffect(() => {
    if (phase !== 'menu' || menuMode !== 'online') return;
    let alive = true;
    const load = async () => {
      try {
        const r = await fetch('/count?XTransformPort=3004', { cache: 'no-store' });
        const j = (await r.json()) as { count?: number };
        if (alive) setOnlineCount(typeof j.count === 'number' ? j.count : null);
      } catch {
        if (alive) setOnlineCount(null);
      }
    };
    load();
    const iv = setInterval(load, 10000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, [phase, menuMode]);

  // ------------------------------------------------------------- actions
  const persist = useCallback(
    (patch: Partial<{ name: string; skinIdx: number; lang: Lang; best: number }>) => {
      saveSave({ ...loadSave(), ...patch });
    },
    [],
  );

  const changeLang = (l: Lang) => {
    setLang(l);
    gameRef.current?.setLang(l);
    persist({ lang: l });
  };

  const changeSkin = (i: number) => {
    setSkinIdx(i);
    persist({ skinIdx: i });
  };

  const changeName = (v: string) => {
    setName(v);
    persist({ name: v });
  };

  const changeMenuMode = (m: MenuMode) => {
    setMenuMode(m);
    menuModeRef.current = m;
    setNetError(null);
  };

  const play = async (roomOverride?: string) => {
    const game = gameRef.current;
    if (!game) return;
    // Re-check touch capability (device/viewport can change after mount).
    const touch = detectTouch();
    setIsTouch(touch);
    // Landscape-first: go fullscreen and try to lock orientation (Android).
    // iOS Safari ignores both — the rotate overlay guides the user instead.
    if (touch) {
      try {
        const el = wrapRef.current;
        if (el && !document.fullscreenElement && el.requestFullscreen) {
          await el.requestFullscreen();
        }
        const so = window.screen.orientation as ScreenOrientation & {
          lock?: (o: 'landscape' | 'portrait' | string) => Promise<void>;
        };
        if (typeof so?.lock === 'function') {
          await so.lock('landscape');
        }
      } catch {
        // Not supported / denied — overlay handles it.
      }
    }
    game.setLang(lang);
    setNetError(null);
    if (menuModeRef.current === 'online') {
      // A valid 4-char code = private room; anything else = global arena.
      const raw = (roomOverride ?? joinCode).trim().toUpperCase();
      const room = ROOM_CODE_RE.test(raw) ? raw : null;
      setRoomCode(room);
      // Make sure the authoritative server is up (it self-spawns on demand).
      try {
        await fetch('/api/arm-net', { cache: 'no-store' });
      } catch {
        // If it is already running this is a no-op; ignore failures.
      }
      game.startOnline(name.trim() || tr.defaultName, skinIdx, room);
    } else {
      setRoomCode(null);
      game.startPlayer(name.trim() || tr.defaultName, skinIdx);
    }
    setHintVisible(true);
    setPhase('play');
  };

  const playAgain = () => {
    const game = gameRef.current;
    if (!game) return;
    if (menuModeRef.current === 'online') {
      game.respawnOnline();
      setPhase('play');
    } else {
      void play();
    }
  };

  const toMenu = () => {
    gameRef.current?.exitToMenu();
    setStats(null);
    setNetStatus('idle');
    setRoomCode(null);
    setPhase('menu');
  };

  /** Copy the invite link of the active room to the clipboard. */
  const copyInvite = async () => {
    if (!roomCode) return;
    const link = `${window.location.origin}/?room=${roomCode}`;
    try {
      await navigator.clipboard.writeText(link);
    } catch {
      try {
        const ta = document.createElement('textarea');
        ta.value = link;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
      } catch {
        // Ignore — the code is still visible on the chip.
      }
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const boostDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.preventDefault();
    gameRef.current?.playerInput.setBoostButton(true);
  };
  const boostUp = () => gameRef.current?.playerInput.setBoostButton(false);

  const fmt = (n: number) => (lang === 'fa' ? n.toLocaleString('fa-IR') : String(n));

  const effectChips: Array<{
    key: keyof Effects;
    icon: ReactNode;
    color: string;
    label: string;
  }> = [
    { key: 'magnet', icon: <Magnet className="h-3.5 w-3.5" />, color: '#E5484D', label: tr.effectMagnet },
    { key: 'x2', icon: <Gem className="h-3.5 w-3.5" />, color: '#00B8D9', label: tr.effectX2 },
    { key: 'ghost', icon: <Ghost className="h-3.5 w-3.5" />, color: '#C9C9D9', label: tr.effectGhost },
    { key: 'frozen', icon: <Snowflake className="h-3.5 w-3.5" />, color: '#7CD4FF', label: tr.effectFrozen },
  ];

  // -------------------------------------------------------------- render
  return (
    <div
      ref={wrapRef}
      className="fixed inset-0 select-none overflow-hidden bg-[#17171C] text-white"
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      {/* ---------------- HUD (playing) ---------------- */}
      {phase === 'play' && (
        <div dir={dir} className="pointer-events-none absolute inset-0 z-10">
          {/* score chips + active power-up effects */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            <div className="rounded-xl bg-black/45 px-3 py-1.5 text-sm font-bold backdrop-blur-sm">
              {tr.score}: <span className="text-amber-400">{stats ? fmt(stats.score) : '0'}</span>
            </div>
            <div className="rounded-xl bg-black/45 px-3 py-1.5 text-xs backdrop-blur-sm">
              {tr.length}: {stats ? fmt(stats.length) : '0'} · {tr.rank}:{' '}
              {stats ? fmt(stats.rank) : '-'}/{stats ? fmt(stats.total) : '-'}
            </div>
            {stats &&
              effectChips
                .filter((c) => (stats.effects[c.key] ?? 0) > 0)
                .map((c) => (
                  <div
                    key={c.key}
                    className="flex w-fit items-center gap-1.5 rounded-xl bg-black/45 px-2.5 py-1 text-xs font-bold backdrop-blur-sm"
                    style={{ color: c.color }}
                  >
                    {c.icon}
                    {c.label}
                    <span className="tabular-nums text-white/80">{fmt(stats.effects[c.key])}</span>
                  </div>
                ))}

            {/* private room chip + waiting hint */}
            {roomCode && (
              <>
                <div className="pointer-events-auto mt-1 flex w-fit items-center gap-2 rounded-xl bg-emerald-500/15 px-2.5 py-1.5 text-xs font-bold backdrop-blur-sm">
                  <Users className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-300">
                    {tr.roomLabel}:{' '}
                    <span dir="ltr" className="tracking-[0.2em]">
                      {roomCode}
                    </span>
                  </span>
                  <span className="text-white/70">
                    {fmt(stats?.players ?? 1)}
                    {tr.roomPlayers}
                  </span>
                  <button
                    type="button"
                    aria-label={tr.copyInvite}
                    onClick={() => void copyInvite()}
                    className="flex h-6 w-6 items-center justify-center rounded-lg bg-emerald-500 text-[#0E1512] transition-colors hover:bg-emerald-400"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                </div>
                {(stats?.players ?? 1) < 2 && (
                  <div className="max-w-[250px] rounded-xl bg-black/45 px-2.5 py-1.5 text-[11px] leading-4 text-emerald-200/90 backdrop-blur-sm">
                    {tr.waitingFriend}
                  </div>
                )}
              </>
            )}
          </div>

          {/* exit to menu */}
          <button
            type="button"
            aria-label={tr.backToMenu}
            onClick={toMenu}
            className="pointer-events-auto absolute top-3 left-1/2 -translate-x-1/2 flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white/80 backdrop-blur-sm transition-colors hover:bg-black/65 hover:text-white"
          >
            <Home className="h-4 w-4" />
          </button>

          {/* leaderboard */}
          <div className="absolute top-3 right-3 w-40 overflow-hidden rounded-xl bg-black/45 backdrop-blur-sm">
            <div className="flex items-center justify-between border-b border-white/10 px-3 py-1.5 text-xs font-bold text-white/70">
              <span>{tr.leaderboard}</span>
              {menuMode === 'online' && <Users className="h-3 w-3 text-emerald-400" />}
            </div>
            {stats?.leaders.map((l, i) => (
              <div
                key={`${l.name}-${i}`}
                className={`flex items-center justify-between px-3 py-1 text-xs ${
                  l.isPlayer ? 'bg-amber-500/20 font-bold text-amber-300' : 'text-white/85'
                }`}
              >
                <span className="truncate">
                  {fmt(i + 1)}. {l.name}
                </span>
                <span className="tabular-nums">{fmt(l.score)}</span>
              </div>
            ))}
          </div>

          {/* hint */}
          {hintVisible && (
            <div className="absolute bottom-28 left-1/2 -translate-x-1/2 rounded-full bg-black/50 px-4 py-2 text-xs text-white/80 backdrop-blur-sm sm:bottom-6">
              {tr.hint}
            </div>
          )}

          {/* boost button (touch) */}
          {isTouch && (
            <button
              type="button"
              aria-label={tr.boost}
              onPointerDown={boostDown}
              onPointerUp={boostUp}
              onPointerCancel={boostUp}
              onPointerLeave={boostUp}
              className="absolute right-5 bottom-6 z-20 h-[76px] w-[76px] touch-none rounded-full bg-amber-500 text-base font-black text-[#17171C] shadow-[0_6px_24px_rgba(245,165,36,0.45)] transition-transform active:scale-90"
            >
              {tr.boost}
            </button>
          )}
        </div>
      )}

      {/* ---------------- ONLINE CONNECTING ---------------- */}
      {phase === 'play' && netStatus === 'connecting' && (
        <div
          dir={dir}
          className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-[#17171C]/85"
        >
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-white/15 border-t-amber-400" />
          <p className="text-sm font-bold text-white/85">{tr.connecting}</p>
        </div>
      )}

      {/* ---------------- INVITE COPIED TOAST ---------------- */}
      {phase === 'play' && copied && (
        <div className="absolute top-16 left-1/2 z-30 -translate-x-1/2 rounded-full bg-emerald-500 px-4 py-1.5 text-xs font-black text-[#0E1512] shadow-lg">
          {tr.inviteCopied}
        </div>
      )}

      {/* ---------------- ROTATE PHONE (touch + portrait) ---------------- */}
      {phase === 'play' && isTouch && isPortrait && (
        <div
          dir={dir}
          className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-5 bg-[#17171C]/95 text-center"
        >
          <RotateCw className="h-14 w-14 animate-pulse text-amber-400" aria-hidden="true" />
          <p className="px-8 text-lg font-bold text-white/90">{tr.rotatePrompt}</p>
        </div>
      )}

      {/* ---------------- MENU ---------------- */}
      {phase === 'menu' && (
        <div
          dir={dir}
          className="absolute inset-0 z-20 flex items-center justify-center overflow-y-auto bg-gradient-to-b from-black/70 via-black/60 to-black/80 p-4"
        >
          <div className="w-[min(92vw,380px)] rounded-3xl border border-white/10 bg-[#1F1F26]/90 p-6 shadow-2xl backdrop-blur-md">
            <h1 className="text-center text-3xl font-black tracking-tight">
              <span className="text-amber-400">{tr.gameTitle}</span>
            </h1>
            <p className="mt-1 text-center text-sm text-white/60">{tr.tagline}</p>

            {/* mode tabs */}
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => changeMenuMode('single')}
                className={`h-10 flex-1 rounded-xl text-xs font-bold transition-colors ${
                  menuMode === 'single'
                    ? 'bg-amber-500 text-[#17171C]'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                {tr.singleMode}
              </button>
              <button
                type="button"
                onClick={() => changeMenuMode('online')}
                className={`flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xl text-xs font-bold transition-colors ${
                  menuMode === 'online'
                    ? 'bg-emerald-500 text-[#17171C]'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                <Users className="h-3.5 w-3.5" />
                {tr.onlineMode}
              </button>
            </div>

            {menuMode === 'online' && (
              <div className="mt-2 rounded-xl bg-emerald-500/10 px-3 py-2 text-center text-xs text-emerald-300">
                {tr.onlineHint}
                {onlineCount !== null && (
                  <span className="mt-0.5 block font-bold">
                    {fmt(onlineCount)} {tr.onlineCount}
                  </span>
                )}
              </div>
            )}

            {/* invite-link banner */}
            {menuMode === 'online' && invitedCode && (
              <div className="mt-2 rounded-xl bg-amber-500/10 px-3 py-2 text-center text-xs text-amber-300">
                {tr.invitedTo}{' '}
                <span dir="ltr" className="font-black tracking-[0.2em]">
                  {invitedCode}
                </span>{' '}
                — {tr.invitedPrompt}
              </div>
            )}

            {netError && (
              <div className="mt-2 rounded-xl bg-rose-500/15 px-3 py-2 text-center text-xs font-bold text-rose-300">
                {netError === 'serverFull'
                  ? tr.serverFull
                  : netError === 'badCode'
                    ? tr.badCode
                    : tr.connLost}
              </div>
            )}

            <div className="mt-4 space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-bold text-white/60">
                  {tr.namePlaceholder}
                </label>
                <Input
                  value={name}
                  onChange={(e) => changeName(e.target.value.slice(0, 12))}
                  placeholder={tr.namePlaceholder}
                  maxLength={12}
                  className="h-11 border-white/15 bg-white/5 text-white placeholder:text-white/30"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-bold text-white/60">{tr.skin}</label>
                <div className="flex flex-wrap gap-2">
                  {SKINS.map((s, i) => (
                    <button
                      key={s.base}
                      type="button"
                      aria-label={`skin ${i + 1}`}
                      onClick={() => changeSkin(i)}
                      className={`h-9 w-9 rounded-full transition-transform ${
                        skinIdx === i
                          ? 'scale-110 ring-2 ring-white ring-offset-2 ring-offset-[#1F1F26]'
                          : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{
                        background: `linear-gradient(135deg, ${s.base} 50%, ${s.stripe} 50%)`,
                      }}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-bold text-white/60">
                  {tr.language}
                </label>
                <div className="flex gap-2">
                  {(['fa', 'en'] as const).map((l) => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => changeLang(l)}
                      className={`h-9 flex-1 rounded-lg text-sm font-bold transition-colors ${
                        lang === l
                          ? 'bg-amber-500 text-[#17171C]'
                          : 'bg-white/5 text-white/60 hover:bg-white/10'
                      }`}
                    >
                      {l === 'fa' ? 'فارسی' : 'English'}
                    </button>
                  ))}
                </div>
              </div>

              {best > 0 && (
                <div className="rounded-xl bg-white/5 px-3 py-2 text-center text-sm">
                  {tr.best}: <span className="font-bold text-amber-400">{fmt(best)}</span>
                </div>
              )}

              {/* private room with a friend (online mode) */}
              {menuMode === 'online' && (
                <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/5 p-3">
                  <div className="mb-2 text-xs font-bold text-emerald-300">
                    {tr.privateRoomTitle}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={joinCode}
                      onChange={(e) =>
                        setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4))
                      }
                      placeholder={tr.roomCodePh}
                      dir="ltr"
                      maxLength={4}
                      className="h-10 flex-1 border-white/15 bg-white/5 text-center font-black tracking-[0.25em] text-white placeholder:font-normal placeholder:tracking-normal placeholder:text-white/30"
                    />
                    <Button
                      type="button"
                      onClick={() => void play()}
                      disabled={joinCode.trim().length !== 4}
                      className="h-10 cursor-pointer rounded-xl bg-emerald-500 px-4 text-sm font-black text-[#17171C] hover:bg-emerald-400 disabled:opacity-40"
                    >
                      {tr.joinRoomBtn}
                    </Button>
                  </div>
                  <Button
                    type="button"
                    onClick={() => void play(makeRoomCode())}
                    className="mt-2 h-10 w-full cursor-pointer rounded-xl bg-emerald-500/90 text-sm font-black text-[#17171C] hover:bg-emerald-400"
                  >
                    {tr.createRoom}
                  </Button>
                  <p className="mt-2 text-[11px] leading-4 text-white/45">{tr.inviteHint}</p>
                </div>
              )}

              <Button
                onClick={() => void play()}
                className={`h-13 w-full cursor-pointer rounded-2xl py-4 text-lg font-black text-[#17171C] ${
                  menuMode === 'online'
                    ? 'bg-emerald-500 hover:bg-emerald-400'
                    : 'bg-amber-500 hover:bg-amber-400'
                }`}
              >
                {menuMode === 'online' ? tr.playOnline : tr.play}
              </Button>

              <p className="text-center text-[11px] leading-5 text-white/40">
                {tr.howToMove}
                <br />
                {tr.howToBoost}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ---------------- DEATH ---------------- */}
      {phase === 'dead' && (
        <div
          dir={dir}
          className="absolute inset-0 z-20 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
        >
          <div className="w-[min(92vw,360px)] rounded-3xl border border-white/10 bg-[#1F1F26]/95 p-6 text-center shadow-2xl">
            <h2 className="text-2xl font-black text-rose-400">{tr.youDied}</h2>

            {newRecord && (
              <div className="mx-auto mt-3 w-fit rounded-full bg-amber-500/20 px-4 py-1 text-sm font-bold text-amber-400">
                {tr.newRecord}
              </div>
            )}

            <div className="mt-5 space-y-2">
              <div className="text-5xl font-black text-amber-400 tabular-nums">{fmt(finalScore)}</div>
              <div className="text-sm text-white/60">{tr.finalScore}</div>
              <div className="pt-1 text-sm text-white/50">
                {tr.best}: <span className="font-bold text-white/80">{fmt(best)}</span>
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <Button
                onClick={playAgain}
                className="h-12 flex-1 cursor-pointer rounded-2xl bg-emerald-500 text-base font-black text-[#17171C] hover:bg-emerald-400"
              >
                {tr.playAgain}
              </Button>
              <Button
                onClick={toMenu}
                variant="secondary"
                className="h-12 flex-1 cursor-pointer rounded-2xl bg-white/10 text-base font-bold text-white hover:bg-white/15"
              >
                {tr.backToMenu}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
