import { CONFIG } from './config';
import type { FoodField } from './food';
import type { SegEntry, SteerInput, Vec } from './types';
import type { Worm } from './worm';

const CELL = 120;

function cellKey(cx: number, cy: number): number {
  return cx * 4096 + cy;
}

const scratch: number[] = [];

/**
 * Bot brain — lightweight steering with TWO skill tiers:
 *
 *  • Pro bots (~30%): avoid danger, occasionally cut off smaller worms,
 *    seek the tastiest food, dodge the border early.
 *  • Dumb bots (~70%): react late and weakly, drift around, sometimes
 *    "fall asleep" and coast in a straight line, never hunt anyone —
 *    easy prey that keeps the game fun for new players.
 */
export function computeBotSteering(
  bot: Worm,
  botIndex: number,
  worms: Worm[],
  segGrid: Map<number, SegEntry[]>,
  food: FoodField,
  time: number,
): SteerInput {
  const P = bot.skill === 0 ? CONFIG.bots.dumb : CONFIG.bots.pro;
  const D = P.dangerRadius;

  // Dumb bots periodically "zone out" and coast straight — free kills.
  if (bot.skill === 0 && Math.sin(time * 0.31 + bot.id * 7.3) > 0.88) {
    return { targetAngle: bot.angle, boosting: false };
  }

  // ---- 1. Danger scan -------------------------------------------------
  let dvx = 0;
  let dvy = 0;
  let force = 0;

  // Border repulsion.
  const m = P.borderMargin;
  const W = CONFIG.world.w;
  const H = CONFIG.world.h;
  if (bot.x < m) {
    const k = (m - bot.x) / m;
    dvx += k * 3;
    force += k;
  }
  if (bot.x > W - m) {
    const k = (bot.x - (W - m)) / m;
    dvx -= k * 3;
    force += k;
  }
  if (bot.y < m) {
    const k = (m - bot.y) / m;
    dvy += k * 3;
    force += k;
  }
  if (bot.y > H - m) {
    const k = (bot.y - (H - m)) / m;
    dvy -= k * 3;
    force += k;
  }

  // Nearby worm bodies / heads.
  const c0x = Math.floor((bot.x - D) / CELL);
  const c1x = Math.floor((bot.x + D) / CELL);
  const c0y = Math.floor((bot.y - D) / CELL);
  const c1y = Math.floor((bot.y + D) / CELL);
  for (let cx = c0x; cx <= c1x; cx++) {
    for (let cy = c0y; cy <= c1y; cy++) {
      const bucket = segGrid.get(cellKey(cx, cy));
      if (!bucket) continue;
      for (const e of bucket) {
        if (e.wi === botIndex) continue; // skip own segments
        const other = worms[e.wi];
        if (!other || !other.alive) continue;
        if (other.ghostT > 0) continue; // ghost bodies are harmless
        const ox = other.segX[e.s];
        const oy = other.segY[e.s];
        const dx = ox - bot.x;
        const dy = oy - bot.y;
        const d2 = dx * dx + dy * dy;
        if (d2 > D * D) continue;
        const d = Math.sqrt(d2) || 1;
        const w = 1 - d / D;
        // Only fear things roughly in front of us (we can't hit what's behind).
        const fx = Math.cos(bot.angle);
        const fy = Math.sin(bot.angle);
        const ahead = (dx / d) * fx + (dy / d) * fy;
        const weight = w * w * (ahead > -0.2 ? 1 : 0.35) * (e.s === 0 ? 2.2 : 1) * P.dangerWeight;
        dvx -= (dx / d) * weight;
        dvy -= (dy / d) * weight;
        force += weight;
      }
    }
  }

  if (force > 0.55) {
    const boost = P.boostPanic && force > 1.15 && bot.score > CONFIG.worm.boostMinScore + 6;
    return { targetAngle: Math.atan2(dvy, dvx), boosting: boost };
  }

  // ---- 2. Aggression: pro bots may cut off a smaller worm ---------------
  if (P.attack && Math.random() < CONFIG.bots.aggression * 0.06) {
    let best: Worm | null = null;
    let bestD = 340;
    for (const w of worms) {
      if (!w.alive || w.id === bot.id) continue;
      if (w.score > bot.score * 0.8) continue;
      const d = Math.hypot(w.x - bot.x, w.y - bot.y);
      if (d < bestD) {
        bestD = d;
        best = w;
      }
    }
    if (best) {
      // Aim ahead of the target's head to block its path.
      const lead = 130;
      const tx = best.x + Math.cos(best.angle) * lead;
      const ty = best.y + Math.sin(best.angle) * lead;
      const boost = bestD < 260 && bot.score > CONFIG.worm.boostMinScore + 10;
      return { targetAngle: Math.atan2(ty - bot.y, tx - bot.x), boosting: boost };
    }
  }

  // ---- 3. Food seek (pro bots value power-ups highly) -------------------
  food.query(bot.x, bot.y, CONFIG.bots.foodSearchRadius, scratch);
  let bestFood: { x: number; y: number } | null = null;
  let bestScore = -1;
  for (const i of scratch) {
    const it = food.items[i];
    if (!it) continue;
    const d = Math.hypot(it.x - bot.x, it.y - bot.y) + 1;
    const tasty = it.kind !== 'norm' ? it.value * (bot.skill === 0 ? 1 : 4) : it.value;
    const s = tasty / d; // tasty-per-distance
    if (s > bestScore) {
      bestScore = s;
      bestFood = it;
    }
  }
  if (bestFood) {
    const boost =
      bot.skill === 1 &&
      Math.hypot(bestFood.x - bot.x, bestFood.y - bot.y) > 380 &&
      bot.score > CONFIG.worm.boostMinScore + 14 &&
      Math.random() < 0.03;
    return { targetAngle: Math.atan2(bestFood.y - bot.y, bestFood.x - bot.x), boosting: boost };
  }

  // ---- 4. Wander toward the map center-ish with noise -------------------
  const noise = Math.sin(time * 0.9 + bot.id * 2.7) * P.wanderNoise;
  const cx = W / 2;
  const cy = H / 2;
  const toCenter = Math.atan2(cy - bot.y, cx - bot.x);
  return { targetAngle: toCenter + noise, boosting: false };
}

/** Pick a spawn position away from walls and other worms' bodies. */
export function findSafeSpawn(
  worms: Worm[],
  segGrid: Map<number, SegEntry[]>,
  out: Vec,
): boolean {
  for (let attempt = 0; attempt < 24; attempt++) {
    const x = 420 + Math.random() * (CONFIG.world.w - 840);
    const y = 420 + Math.random() * (CONFIG.world.h - 840);
    if (spawnIsClear(worms, segGrid, x, y)) {
      out.x = x;
      out.y = y;
      return true;
    }
  }
  out.x = 420 + Math.random() * (CONFIG.world.w - 840);
  out.y = 420 + Math.random() * (CONFIG.world.h - 840);
  return true;
}

function spawnIsClear(
  worms: Worm[],
  segGrid: Map<number, SegEntry[]>,
  x: number,
  y: number,
): boolean {
  const R = 300;
  const c0x = Math.floor((x - R) / CELL);
  const c1x = Math.floor((x + R) / CELL);
  const c0y = Math.floor((y - R) / CELL);
  const c1y = Math.floor((y + R) / CELL);
  for (let cx = c0x; cx <= c1x; cx++) {
    for (let cy = c0y; cy <= c1y; cy++) {
      const bucket = segGrid.get(cellKey(cx, cy));
      if (!bucket) continue;
      for (const e of bucket) {
        const w = worms[e.wi];
        if (!w || !w.alive) continue;
        const dx = w.segX[e.s] - x;
        const dy = w.segY[e.s] - y;
        if (dx * dx + dy * dy < R * R) return false;
      }
    }
  }
  return true;
}
