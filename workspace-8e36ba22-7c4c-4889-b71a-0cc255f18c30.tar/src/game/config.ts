/**
 * All gameplay tunables in one place.
 * Tweak numbers here to balance the game without touching logic.
 */
export const CONFIG = {
  world: {
    w: 4400,
    h: 4400,
  },

  food: {
    targetCount: 520, // normal food items kept on the map
    baseValue: 1,
    bigChance: 0.06,
    bigValue: 5,
    baseRadius: 5,
    bigRadius: 9,
    magnetDist: 95, // food starts flying toward the head
    magnetSpeed: 430,
    scatterDecay: 4.5, // dropped food velocity decay
  },

  worm: {
    startScore: 10,
    startLength: 16, // segments
    maxSegments: 220,
    scorePerSegment: 3, // every N score = 1 extra segment
    segSpacing: 9, // spacing at baseRadius — grows with girth
    baseRadius: 11,
    radiusMax: 38, // worms get noticeably THICKER as they eat (Worms Zone style)
    radiusFactor: 0.95, // radius = base + sqrt(score) * factor
    spacingPerRadius: 0.42, // extra segment spacing per radius unit above base
    headScale: 1.12, // head slightly bigger than body segments
    baseSpeed: 175,
    boostSpeed: 330,
    accelK: 8, // speed ramp responsiveness (higher = punchier)
    turnRate: 5.0, // radians per second at base size
    turnPerRadius: 0.013, // big worms turn a bit slower
    boostDrain: 0, // boost is FREE like Worms Zone — no score drain
    boostMinScore: 0,
    hitFactor: 0.82, // forgiveness factor on collision radii
  },

  powerup: {
    kinds: ['magnet', 'x2', 'ghost', 'freeze'] as const,
    colors: { magnet: '#E5484D', x2: '#00B8D9', ghost: '#C9C9D9', freeze: '#7CD4FF' },
    radius: 13,
    value: 3, // small score bump when eaten
    maxOnMap: 9,
    spawnEvery: 6, // seconds between spawn attempts
    magnetDist: 330, // magnet radius while active (default is food.magnetDist)
    magnetDur: 9,
    x2Dur: 10,
    ghostDur: 7,
    freezeDur: 5,
    freezeRadius: 520, // freezes OTHER worms within this radius
    freezeFactor: 0.45, // frozen worms move/turn at this fraction
  },

  bots: {
    count: 12,
    respawnDelay: 2.5, // seconds
    foodSearchRadius: 520,
    aggression: 0.22, // pro bots only: chance to try cutting off a smaller worm
    dumbRatio: 0.7, // 70% of bots are easy prey, 30% stay sharp
    dumb: {
      dangerRadius: 135, // reacts late
      dangerWeight: 0.55, // ...and weakly
      borderMargin: 190, // barely avoids the wall
      turnMul: 0.62, // slow to turn
      wanderNoise: 2.6, // drifts around
      attack: false, // never hunts the player
      boostPanic: false, // doesn't panic-boost away
    },
    pro: {
      dangerRadius: 225,
      dangerWeight: 1,
      borderMargin: 300,
      turnMul: 1,
      wanderNoise: 0.6,
      attack: true,
      boostPanic: true,
    },
  },

  camera: {
    minZoom: 0.55,
    maxZoom: 1.16,
    followLerp: 6.5,
    zoomLerp: 3,
  },

  particles: {
    maxCount: 260,
  },
} as const;

/** Flat vibrant skins (base color + darker stripe color). */
export const SKINS: ReadonlyArray<{ base: string; stripe: string }> = [
  { base: '#F5A524', stripe: '#D98A0B' },
  { base: '#F0417C', stripe: '#C22963' },
  { base: '#30A46C', stripe: '#237B51' },
  { base: '#9B59F6', stripe: '#7A3ED4' },
  { base: '#F76B15', stripe: '#CE5510' },
  { base: '#12A594', stripe: '#0D7D71' },
  { base: '#9BD932', stripe: '#79B421' },
  { base: '#FF7AB8', stripe: '#E0559C' },
];

/** Palette for food dots. */
export const FOOD_COLORS: ReadonlyArray<string> = [
  '#F5A524',
  '#E5484D',
  '#30A46C',
  '#E93D82',
  '#B273F2',
  '#00B8D9',
  '#F76B15',
  '#FFC53D',
  '#7CE2A0',
];

export const WORLD_BG = '#17171C';
export const GRID_COLOR = 'rgba(255,255,255,0.05)';
export const BORDER_COLOR = '#E5484D';
