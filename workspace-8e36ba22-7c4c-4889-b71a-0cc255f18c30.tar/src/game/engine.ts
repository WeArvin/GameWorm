import { computeBotSteering, findSafeSpawn } from './bot';
import { CONFIG, SKINS } from './config';
import { FoodField } from './food';
import { InputController } from './input';
import { BOT_NAMES } from './i18n';
import {
  NetClient,
  FLAG_BOT,
  FLAG_BOOST,
  FLAG_FROZEN,
  FLAG_GHOST,
  FLAG_MAGNET,
  FLAG_X2,
  type NetWormState,
} from './net';
import { renderGame } from './render';
import type { Effects, GameMode, Lang, NetFood, Particle, SegEntry, Stats, Vec } from './types';
import { Worm } from './worm';

const CELL = 120;

function cellKey(cx: number, cy: number): number {
  return cx * 4096 + cy;
}

export interface GameOptions {
  onStats?: (s: Stats) => void;
  onDeath?: (score: number) => void;
  onNetStatus?: (s: 'connecting' | 'connected' | 'error' | 'closed' | 'full' | 'badCode') => void;
}

/**
 * The game engine: world state, fixed-ish update loop, collisions,
 * camera, particles, special power-ups and three modes:
 *  demo  — bots playing behind the menu
 *  play  — single player vs bots (offline)
 *  online — real multiplayer; the server (mini-service) is authoritative,
 *           clients predict locally and reconcile against snapshots.
 */
export class Game {
  readonly canvas: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;

  mode: GameMode = 'demo';
  lang: Lang = 'fa';
  time = 0;
  paused = false;

  worms: Worm[] = [];
  particles: Particle[] = [];
  cam = { x: CONFIG.world.w / 2, y: CONFIG.world.h / 2, zoom: 1, scale: 1 };
  private nextId = 0;
  private player: Worm | null = null;
  private demoHero: Worm | null = null;
  private demoHeroTimer = 0;

  food = new FoodField(CONFIG.world.w, CONFIG.world.h);
  private segGrid = new Map<number, SegEntry[]>();
  private doomed = new Set<number>();
  private boostTrails = new Map<number, number>(); // worm.id -> timer (visual streaks only)
  private powerupTimer = 0;
  private botRespawns: number[] = [];
  private playerDied = false;
  private killfeedMsg = '';

  // ---- Online state ---------------------------------------------------
  private net: NetClient | null = null;
  private myNetId = -1;
  private onlineRoom: string | null = null;
  private remoteWorms = new Map<number, Worm>();
  private netTargets = new Map<number, { x: number; y: number; ang: number; score: number }>();
  private netSendTimer = 0;

  private input: InputController;
  private scratchSeg: Vec[] = [];

  private raf = 0;
  private lastTs = 0;
  private statsTimer = 0;
  private destroyed = false;

  private onStats?: (s: Stats) => void;
  private onDeath?: (score: number) => void;
  private onNetStatus?: (
    s: 'connecting' | 'connected' | 'error' | 'closed' | 'full' | 'badCode',
  ) => void;

  constructor(canvas: HTMLCanvasElement, opts: GameOptions = {}) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D not supported');
    this.ctx = ctx;
    this.onStats = opts.onStats;
    this.onDeath = opts.onDeath;
    this.onNetStatus = opts.onNetStatus;

    this.input = new InputController(canvas);
    this.food.init(CONFIG.food.targetCount);
    this.resize();

    for (let i = 0; i < CONFIG.bots.count; i++) this.spawnBot();
    this.pickDemoHero(true);

    this.net = new NetClient({
      onWelcome: (id, worms, food, room) => this.netWelcome(id, worms, food, room),
      onSnapshot: (worms, eaten) => this.netSnapshot(worms, eaten),
      onFoodAdd: (items) => this.food.serverAdd(items),
      onDied: (id, _name, score) => this.netDied(id, score),
      onRespawned: (st) => this.netRespawned(st),
      onFull: () => {
        this.resetLocalWorld();
        this.onNetStatus?.('full');
      },
      onBadRoom: () => {
        this.resetLocalWorld();
        this.onNetStatus?.('badCode');
      },
      onStatus: (s) => {
        if (s === 'closed' || s === 'error') {
          if (this.mode === 'online') {
            this.resetLocalWorld();
          }
        }
        this.onNetStatus?.(s);
      },
    });

    this.lastTs = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
    // Debug/testing hook (harmless in production).
    if (typeof window !== 'undefined') {
      (window as unknown as { __worm?: Game }).__worm = this;
    }
  }

  setLang(lang: Lang): void {
    this.lang = lang;
  }

  // ------------------------------------------------------------------
  // Spawning (local world: demo + single player)
  // ------------------------------------------------------------------

  private spawnBot(): void {
    const names = BOT_NAMES[this.lang];
    const name = names[(Math.random() * names.length) | 0];
    const bot = new Worm(this.nextId++, name, SKINS[(Math.random() * SKINS.length) | 0], false);
    // ~70% dumb bots (easy prey), ~30% sharp ones (keeps it interesting).
    bot.skill = Math.random() < CONFIG.bots.dumbRatio ? 0 : 1;
    const pos: Vec = { x: 0, y: 0 };
    findSafeSpawn(this.worms, this.segGrid, pos);
    bot.reset(pos.x, pos.y, Math.random() * Math.PI * 2, CONFIG.worm.startScore + Math.random() * 60);
    this.worms.push(bot);
  }

  startPlayer(name: string, skinIdx: number): void {
    if (this.mode === 'online') this.resetLocalWorld();
    const player = new Worm(this.nextId++, name, SKINS[skinIdx % SKINS.length], true);
    const pos: Vec = { x: 0, y: 0 };
    findSafeSpawn(this.worms, this.segGrid, pos);
    player.reset(pos.x, pos.y, Math.random() * Math.PI * 2, CONFIG.worm.startScore);
    this.worms.push(player);
    this.player = player;
    this.mode = 'play';
    this.cam.x = player.x;
    this.cam.y = player.y;
    this.emitStats();
  }

  /** Join the online arena (server-authoritative). `room` = 4-char invite code. */
  startOnline(name: string, skinIdx: number, room?: string | null): void {
    this.mode = 'online';
    this.onlineRoom = (room ?? '').trim().toUpperCase() || null;
    this.player = null;
    this.worms.length = 0;
    this.food.items.length = 0;
    this.food.markDirty();
    this.net?.connect(name.trim() || 'Worm', skinIdx, this.onlineRoom);
  }

  /** Invite code of the current online room (null = global arena). */
  get roomCode(): string | null {
    return this.onlineRoom;
  }

  /** Ask the server for a fresh spawn (after dying online). */
  respawnOnline(): void {
    this.net?.requestRespawn();
  }

  exitToMenu(): void {
    if (this.mode === 'online') {
      this.resetLocalWorld();
      this.onNetStatus?.('closed');
    } else {
      this.removePlayer();
      this.mode = 'demo';
      this.pickDemoHero(true);
    }
  }

  /** Tear down online state and rebuild the offline bot world. */
  private resetLocalWorld(): void {
    this.net?.disconnect();
    this.myNetId = -1;
    this.remoteWorms.clear();
    this.netTargets.clear();
    this.player = null;
    this.worms.length = 0;
    this.botRespawns.length = 0;
    this.food.init(CONFIG.food.targetCount);
    for (let i = 0; i < CONFIG.bots.count; i++) this.spawnBot();
    this.mode = 'demo';
    this.pickDemoHero(true);
  }

  private removePlayer(): void {
    if (!this.player) return;
    const i = this.worms.indexOf(this.player);
    if (i >= 0) this.worms.splice(i, 1);
    this.player = null;
  }

  private pickDemoHero(force = false): void {
    if (!force && this.demoHero && this.demoHero.alive) return;
    const bots = this.worms.filter((w) => w.alive && !w.isPlayer);
    this.demoHero = bots.length > 0 ? bots[(Math.random() * bots.length) | 0] : null;
    this.demoHeroTimer = 0;
  }

  // ------------------------------------------------------------------
  // Online: network message handling
  // ------------------------------------------------------------------

  private skinByIdx(i: number) {
    return SKINS[((i % SKINS.length) + SKINS.length) % SKINS.length];
  }

  private applyFlags(w: Worm, flags: number): void {
    w.magnetT = flags & FLAG_MAGNET ? 0.3 : 0;
    w.x2T = flags & FLAG_X2 ? 0.3 : 0;
    w.ghostT = flags & FLAG_GHOST ? 0.3 : 0;
    w.frozenT = flags & FLAG_FROZEN ? 0.3 : 0;
    w.boosting = (flags & FLAG_BOOST) !== 0;
    w.isBot = (flags & FLAG_BOT) !== 0;
  }

  private createRemoteWorm(st: NetWormState): Worm {
    const [id, x, y, ang, score, flags, name, skinIdx] = st;
    const w = new Worm(id, name, this.skinByIdx(skinIdx), false);
    w.isRemote = true;
    w.reset(x, y, ang, score);
    this.applyFlags(w, flags);
    this.worms.push(w);
    this.remoteWorms.set(id, w);
    this.netTargets.set(id, { x, y, ang, score });
    return w;
  }

  private netWelcome(id: number, worms: NetWormState[], food: NetFood[], room: string | null): void {
    this.myNetId = id;
    this.onlineRoom = room ?? null;
    this.food.setServerItems(food);
    this.food.markDirty();

    for (const st of worms) {
      const [wid, x, y, ang, score, flags, name, skinIdx] = st;
      if (wid === id) {
        // My worm — full local prediction from the server spawn.
        const p = new Worm(id, name, this.skinByIdx(skinIdx), true);
        p.reset(x, y, ang, score);
        this.applyFlags(p, flags);
        this.worms.push(p);
        this.player = p;
        this.cam.x = p.x;
        this.cam.y = p.y;
        this.cam.zoom = 1;
      } else {
        this.createRemoteWorm(st);
      }
    }
    this.emitStats();
  }

  private netSnapshot(worms: NetWormState[], eaten: Array<[number, number, number]>): void {
    if (this.mode !== 'online') return;

    // Eaten food → particles + removal.
    if (eaten.length > 0) {
      for (const [, ex, ey] of eaten) {
        if (this.particles.length < CONFIG.particles.maxCount) {
          this.spawnParticles(ex, ey, 2, '#FFFFFF', 70);
        }
      }
      this.food.serverRemove(eaten.map((e) => e[0]));
    }

    const seen = new Set<number>();
    for (const st of worms) {
      const [id, x, y, ang, score, flags] = st;
      seen.add(id);
      if (id === this.myNetId) {
        const p = this.player;
        if (!p) continue;
        // Soft reconciliation toward the server position.
        const err = Math.hypot(x - p.x, y - p.y);
        if (err > 260) {
          p.x = x;
          p.y = y;
        } else if (err > 1) {
          p.x += (x - p.x) * 0.08;
          p.y += (y - p.y) * 0.08;
        }
        p.score = score;
        this.applyFlags(p, flags);
      } else {
        let w = this.remoteWorms.get(id);
        if (!w) w = this.createRemoteWorm(st);
        const t = this.netTargets.get(id);
        if (t) {
          t.x = x;
          t.y = y;
          t.ang = ang;
          t.score = score;
        }
        w.name = st[6];
        w.skin = this.skinByIdx(st[7]);
        this.applyFlags(w, flags);
      }
    }

    // Remove remote worms that vanished from the snapshot (disconnected).
    for (const [id, w] of this.remoteWorms) {
      if (seen.has(id)) continue;
      const i = this.worms.indexOf(w);
      if (i >= 0) this.worms.splice(i, 1);
      this.remoteWorms.delete(id);
      this.netTargets.delete(id);
    }
  }

  private netDied(id: number, score: number): void {
    const w = id === this.myNetId ? this.player : this.remoteWorms.get(id);
    if (!w) return;
    this.spawnParticles(w.x, w.y, 16, w.skin.base, 140);
    const i = this.worms.indexOf(w);
    if (i >= 0) this.worms.splice(i, 1);
    this.remoteWorms.delete(id);
    this.netTargets.delete(id);
    if (id === this.myNetId) {
      this.player = null;
      this.onDeath?.(Math.floor(score));
    }
  }

  private netRespawned(st: NetWormState): void {
    if (this.mode !== 'online') return;
    const [id, x, y, ang, score, , name, skinIdx] = st;
    if (this.player) {
      const i = this.worms.indexOf(this.player);
      if (i >= 0) this.worms.splice(i, 1);
      this.player = null;
    }
    const p = new Worm(id, name, this.skinByIdx(skinIdx), true);
    p.reset(x, y, ang, score);
    this.worms.push(p);
    this.player = p;
    this.cam.x = p.x;
    this.cam.y = p.y;
  }

  // ------------------------------------------------------------------
  // Loop
  // ------------------------------------------------------------------

  private loop(ts: number): void {
    if (this.destroyed) return;
    const dt = Math.min(0.05, (ts - this.lastTs) / 1000);
    this.lastTs = ts;
    if (!this.paused) this.update(dt);
    renderGame(this);
    this.raf = requestAnimationFrame(this.loop);
  }

  /** Freeze the whole world (e.g. "rotate your phone" overlay). */
  setPaused(v: boolean): void {
    this.paused = v;
  }

  private update(dt: number): void {
    this.time += dt;

    if (this.mode === 'online') {
      this.updateOnline(dt);
      return;
    }

    // Build the segment spatial hash for this frame.
    this.buildSegGrid();

    // Player steering.
    if (this.player && this.player.alive) {
      this.input.update(this.player.angle);
      this.player.targetAngle = this.input.targetAngle;
      this.player.update(dt, {
        targetAngle: this.input.targetAngle,
        boosting: this.input.boosting,
      });
    }

    // Bot steering.
    for (let bi = 0; bi < this.worms.length; bi++) {
      const w = this.worms[bi];
      if (w.isPlayer || !w.alive) continue;
      const steer = computeBotSteering(w, bi, this.worms, this.segGrid, this.food, this.time);
      w.update(dt, steer);
    }

    // Boost streaks: pure visual particles — boost NEVER drops food.
    for (const w of this.worms) {
      if (!w.alive || !w.boosting) {
        this.boostTrails.delete(w.id);
        continue;
      }
      const t = (this.boostTrails.get(w.id) ?? 0) + dt;
      if (t >= 0.08) {
        this.boostTrails.delete(w.id);
        const tail = this.wormTail(w);
        this.spawnParticles(tail.x, tail.y, 2, w.skin.stripe, 55);
      } else {
        this.boostTrails.set(w.id, t);
      }
    }

    this.checkDeaths();
    this.food.update(dt);
    this.updateFoodEating(false);

    // Refill food + keep the map stocked with power-ups + respawn bots.
    this.food.topUp(CONFIG.food.targetCount);
    this.powerupTimer += dt;
    if (this.powerupTimer >= CONFIG.powerup.spawnEvery) {
      this.powerupTimer = 0;
      if (this.food.countPowerups() < CONFIG.powerup.maxOnMap) this.food.spawnPowerup();
    }
    for (let i = this.botRespawns.length - 1; i >= 0; i--) {
      this.botRespawns[i] -= dt;
      if (this.botRespawns[i] <= 0) {
        this.botRespawns.splice(i, 1);
        this.spawnBot();
      }
    }

    this.updateParticles(dt);
    this.updateCamera(dt);

    // Demo hero rotation.
    if (this.mode === 'demo') {
      this.demoHeroTimer += dt;
      if (this.demoHeroTimer > 12) this.pickDemoHero(true);
      else this.pickDemoHero();
    }

    // Stats for the React HUD.
    if (this.mode === 'play') {
      this.statsTimer += dt;
      if (this.statsTimer >= 0.3) {
        this.statsTimer = 0;
        this.emitStats();
      }
    }
  }

  /** Online tick: local prediction + remote interpolation. */
  private updateOnline(dt: number): void {
    // Own worm: full local simulation (zero input latency).
    if (this.player && this.player.alive) {
      this.input.update(this.player.angle);
      this.player.targetAngle = this.input.targetAngle;
      this.player.update(dt, {
        targetAngle: this.input.targetAngle,
        boosting: this.input.boosting,
      });
      // Send steering to the server at ~12 Hz.
      this.netSendTimer += dt;
      if (this.netSendTimer >= 0.08) {
        this.netSendTimer = 0;
        this.net?.sendInput(this.player.targetAngle, this.input.boosting);
      }
    }

    // Remote worms: smooth toward their latest network target.
    const k = Math.min(1, 10 * dt);
    for (const w of this.remoteWorms.values()) {
      const t = this.netTargets.get(w.id);
      if (!t) continue;
      w.x += (t.x - w.x) * k;
      w.y += (t.y - w.y) * k;
      let da = t.ang - w.angle;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      w.angle += da * Math.min(1, 12 * dt);
      w.score = t.score;
      w.followPath(dt);
    }

    // Local magnet VISUAL: pull food toward our head (server decides eats).
    if (this.player && this.player.alive) this.updateFoodEating(true);

    this.food.update(dt);
    this.updateParticles(dt);
    this.updateCamera(dt);

    this.statsTimer += dt;
    if (this.statsTimer >= 0.3) {
      this.statsTimer = 0;
      this.emitStats();
    }
  }

  private wormTail(w: Worm): Vec {
    const n = w.segX.length;
    return { x: w.segX[n - 1] ?? w.x, y: w.segY[n - 1] ?? w.y };
  }

  // ------------------------------------------------------------------
  // Spatial hash of all worm segments (for collisions + bot senses)
  // ------------------------------------------------------------------

  private buildSegGrid(): void {
    this.segGrid.clear();
    for (let wi = 0; wi < this.worms.length; wi++) {
      const w = this.worms[wi];
      if (!w.alive) continue;
      const n = w.segX.length;
      const step = n > 60 ? 2 : 1; // sample long bodies a bit sparser
      for (let s = 0; s < n; s += step) {
        const key = cellKey(Math.floor(w.segX[s] / CELL), Math.floor(w.segY[s] / CELL));
        const bucket = this.segGrid.get(key);
        if (bucket) bucket.push({ wi, s });
        else this.segGrid.set(key, [{ wi, s }]);
      }
      // Always include the head.
      if (step !== 1) {
        const key = cellKey(Math.floor(w.x / CELL), Math.floor(w.y / CELL));
        const bucket = this.segGrid.get(key);
        if (bucket) bucket.push({ wi, s: 0 });
        else this.segGrid.set(key, [{ wi, s: 0 }]);
      }
    }
  }

  // ------------------------------------------------------------------
  // Collisions
  // ------------------------------------------------------------------

  private checkDeaths(): void {
    this.doomed.clear();
    const W = CONFIG.world.w;
    const H = CONFIG.world.h;
    const HF = CONFIG.worm.hitFactor;

    for (let wi = 0; wi < this.worms.length; wi++) {
      const w = this.worms[wi];
      if (!w.alive) continue;

      // Ghost worms are untouchable.
      if (w.ghostT > 0) continue;

      // Border kills.
      if (w.x < 0 || w.y < 0 || w.x > W || w.y > H) {
        this.doomed.add(wi);
        continue;
      }

      const r = w.radius;
      const c0x = Math.floor((w.x - r - 30) / CELL);
      const c1x = Math.floor((w.x + r + 30) / CELL);
      const c0y = Math.floor((w.y - r - 30) / CELL);
      const c1y = Math.floor((w.y + r + 30) / CELL);

      outer: for (let cx = c0x; cx <= c1x; cx++) {
        for (let cy = c0y; cy <= c1y; cy++) {
          const bucket = this.segGrid.get(cellKey(cx, cy));
          if (!bucket) continue;
          for (const e of bucket) {
            if (e.wi === wi) continue; // no self collision
            const other = this.worms[e.wi];
            if (!other || !other.alive) continue;
            if (other.ghostT > 0) continue; // ghost bodies are harmless
            const dx = other.segX[e.s] - w.x;
            const dy = other.segY[e.s] - w.y;
            const rr = (r + other.radius) * HF;
            if (dx * dx + dy * dy < rr * rr) {
              if (e.s === 0) {
                // Head-to-head: the smaller worm loses.
                if (w.score > other.score) this.doomed.add(this.worms.indexOf(other));
                else if (other.score > w.score) this.doomed.add(wi);
                else {
                  this.doomed.add(wi);
                  this.doomed.add(this.worms.indexOf(other));
                }
              } else {
                this.doomed.add(wi);
              }
              if (this.doomed.has(wi)) break outer;
            }
          }
        }
      }
    }

    if (this.doomed.size === 0) return;
    for (const wi of this.doomed) {
      const w = this.worms[wi];
      if (w && w.alive) this.killWorm(w);
    }

    // Handle player death AFTER the loop (indices stay valid while iterating).
    if (this.playerDied) {
      this.playerDied = false;
      const score = this.player ? Math.floor(this.player.score) : 0;
      this.removePlayer();
      this.mode = 'demo';
      this.pickDemoHero(true);
      this.onDeath?.(score);
    }
  }

  private killWorm(w: Worm): void {
    w.alive = false;
    // Drop food along the body.
    this.scratchSeg.length = 0;
    for (let s = 0; s < w.segX.length; s += 2) {
      this.scratchSeg.push({ x: w.segX[s], y: w.segY[s] });
    }
    this.food.scatter(this.scratchSeg, 2, w.skin.base);
    this.spawnParticles(w.x, w.y, 14, w.skin.base, 130);
    this.killfeedMsg = w.name;

    if (w.isPlayer) {
      this.playerDied = true;
    } else {
      this.botRespawns.push(CONFIG.bots.respawnDelay);
    }
  }

  // ------------------------------------------------------------------
  // Food eating (magnet + consume + power-ups)
  // ------------------------------------------------------------------

  /**
   * @param pullOnly online mode: animate the magnet pull but let the
   *                 server decide what is actually eaten.
   */
  private updateFoodEating(pullOnly: boolean): void {
    const toRemove: number[] = [];
    const magnetR = CONFIG.food.magnetSpeed;

    for (const w of this.worms) {
      if (!w.alive) continue;
      const r = w.radius;
      const magnet = w.magnetT > 0 ? CONFIG.powerup.magnetDist : CONFIG.food.magnetDist;
      this.food.query(w.x, w.y, magnet, this.foodQuery);
      for (const i of this.foodQuery) {
        const it = this.food.items[i];
        if (!it) continue;
        const dx = w.x - it.x;
        const dy = w.y - it.y;
        const d = Math.hypot(dx, dy);
        if (d < r + it.r + 3) {
          if (pullOnly) continue; // server is authoritative online
          this.consumeFood(w, it);
          toRemove.push(i);
        } else if (d < magnet + r) {
          // Pull toward the head.
          const s = (magnetR * 0.016) / Math.max(d, 1);
          it.x += dx * s;
          it.y += dy * s;
        }
      }
    }

    this.food.removeIndices(toRemove);
  }
  private foodQuery: number[] = [];

  /** Apply score + power-up effects for a eaten food item. */
  private consumeFood(w: Worm, it: { kind: string; value: number; color: string; x: number; y: number }): void {
    const mult = w.x2T > 0 ? 2 : 1;
    w.score += it.value * mult;
    this.spawnParticles(it.x, it.y, 3, it.color, 90);

    switch (it.kind) {
      case 'magnet':
        w.magnetT = CONFIG.powerup.magnetDur;
        break;
      case 'x2':
        w.x2T = CONFIG.powerup.x2Dur;
        break;
      case 'ghost':
        w.ghostT = CONFIG.powerup.ghostDur;
        break;
      case 'freeze': {
        // Freeze every OTHER worm around the eater.
        const R = CONFIG.powerup.freezeRadius;
        for (const o of this.worms) {
          if (o === w || !o.alive) continue;
          if (Math.hypot(o.x - w.x, o.y - w.y) < R) {
            o.frozenT = CONFIG.powerup.freezeDur;
            this.spawnParticles(o.x, o.y, 6, CONFIG.powerup.colors.freeze, 80);
          }
        }
        break;
      }
      default:
        break;
    }

    if (it.kind !== 'norm') {
      this.spawnParticles(it.x, it.y, 10, it.color, 130);
    }
  }

  // ------------------------------------------------------------------
  // Particles
  // ------------------------------------------------------------------

  private spawnParticles(x: number, y: number, n: number, color: string, speed: number): void {
    for (let i = 0; i < n; i++) {
      if (this.particles.length >= CONFIG.particles.maxCount) return;
      const a = Math.random() * Math.PI * 2;
      const v = speed * (0.4 + Math.random() * 0.6);
      const life = 0.35 + Math.random() * 0.3;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * v,
        vy: Math.sin(a) * v,
        r: 2 + Math.random() * 2.5,
        life,
        maxLife: life,
        color,
      });
    }
  }

  private updateParticles(dt: number): void {
    const k = Math.max(0, 1 - 3.5 * dt);
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles[i] = this.particles[this.particles.length - 1];
        this.particles.pop();
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= k;
      p.vy *= k;
    }
  }

  // ------------------------------------------------------------------
  // Camera
  // ------------------------------------------------------------------

  private updateCamera(dt: number): void {
    let target: Vec | null = null;
    if ((this.mode === 'play' || this.mode === 'online') && this.player) {
      target = this.player;
    } else if (this.mode === 'online') {
      target = null; // dead online player: hold the camera still
    } else if (this.demoHero && this.demoHero.alive) {
      target = this.demoHero;
    } else {
      this.pickDemoHero(true);
      target = this.demoHero;
    }

    const C = CONFIG.camera;
    if (target) {
      const l = Math.min(1, C.followLerp * dt);
      this.cam.x += (target.x - this.cam.x) * l;
      this.cam.y += (target.y - this.cam.y) * l;
    }

    let zoomTarget = 0.92;
    if ((this.mode === 'play' || this.mode === 'online') && this.player) {
      const rr = this.player.radius;
      zoomTarget = Math.max(C.minZoom, Math.min(C.maxZoom, 1.16 - (rr - CONFIG.worm.baseRadius) * 0.045));
      if (this.player.boosting) zoomTarget *= 0.97; // slight FOV punch while boosting
    }
    this.cam.zoom += (zoomTarget - this.cam.zoom) * Math.min(1, C.zoomLerp * dt);

    const w = this.canvas.clientWidth || 1;
    const h = this.canvas.clientHeight || 1;
    const base = Math.max(0.5, Math.min(1.25, Math.min(w, h) / 780));
    this.cam.scale = base * this.cam.zoom;
  }

  // ------------------------------------------------------------------
  // Stats
  // ------------------------------------------------------------------

  private emitStats(): void {
    if (!this.onStats) return;
    const alive = this.worms.filter((w) => w.alive).sort((a, b) => b.score - a.score);
    const leaders = alive.slice(0, 5).map((w) => ({
      name: w.name,
      score: Math.floor(w.score),
      isPlayer: w.isPlayer,
    }));
    let rank = alive.length;
    let total = alive.length;
    let score = 0;
    let length = 0;
    let players = 0;
    const effects: Effects = { magnet: 0, x2: 0, ghost: 0, frozen: 0 };
    if (this.player) {
      rank = alive.findIndex((w) => w.isPlayer) + 1;
      score = Math.floor(this.player.score);
      length = this.player.segments;
      effects.magnet = Math.max(0, Math.ceil(this.player.magnetT));
      effects.x2 = Math.max(0, Math.ceil(this.player.x2T));
      effects.ghost = Math.max(0, Math.ceil(this.player.ghostT));
      effects.frozen = Math.max(0, Math.ceil(this.player.frozenT));
    }
    if (rank === 0) rank = total;
    // Online: count real humans (remote worms that are not server bots).
    if (this.mode === 'online') {
      players = alive.filter((w) => w.isPlayer || (w.isRemote && !w.isBot)).length;
    }
    this.onStats({ score, length, rank, total, players, leaders, effects });
  }

  get killfeed(): string {
    return this.killfeedMsg;
  }

  // ------------------------------------------------------------------
  // Resize + teardown
  // ------------------------------------------------------------------

  resize(): void {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  destroy(): void {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    this.input.destroy();
    this.net?.disconnect();
  }

  get playerWorm(): Worm | null {
    return this.player;
  }

  get playerInputJoystick() {
    return this.input.joystick;
  }

  get playerInput(): InputController {
    return this.input;
  }
}
