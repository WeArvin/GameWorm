import { CONFIG, FOOD_COLORS } from './config';
import type { FoodItem, NetFood, PowerupKind, Vec } from './types';

const CELL = 120; // spatial hash cell size (world px)

function cellKey(cx: number, cy: number): number {
  return cx * 4096 + cy;
}

const KINDS: ReadonlyArray<PowerupKind> = ['norm', 'magnet', 'x2', 'ghost', 'freeze'];

export function kindIndex(kind: PowerupKind): number {
  return KINDS.indexOf(kind);
}

export function kindFromIndex(i: number): PowerupKind {
  return KINDS[i] ?? 'norm';
}

/**
 * Food field with a spatial hash grid for fast neighborhood queries.
 * Includes Worms Zone-style special items (magnet / x2 / ghost / freeze).
 */
export class FoodField {
  items: FoodItem[] = [];
  private grid = new Map<number, number[]>();
  private dirty = true;
  private w: number;
  private h: number;
  private nextId = 1;

  constructor(w: number, h: number) {
    this.w = w;
    this.h = h;
  }

  get count(): number {
    return this.items.length;
  }

  /** Highest assigned id (for delta sync). */
  get lastId(): number {
    return this.nextId - 1;
  }

  /** Force the spatial hash to rebuild on the next query. */
  markDirty(): void {
    this.dirty = true;
  }

  /** Items with id above `minId` (delta sync). */
  itemsSince(minId: number): FoodItem[] {
    return this.items.filter((it) => it.id > minId);
  }

  init(count: number): void {
    this.items.length = 0;
    for (let i = 0; i < count; i++) {
      this.items.push(this.makeRandom());
    }
    this.dirty = true;
  }

  private randomPos(): Vec {
    return {
      x: 60 + Math.random() * (this.w - 120),
      y: 60 + Math.random() * (this.h - 120),
    };
  }

  private makeRandom(): FoodItem {
    const big = Math.random() < CONFIG.food.bigChance;
    const p = this.randomPos();
    return {
      id: this.nextId++,
      x: p.x,
      y: p.y,
      r: big ? CONFIG.food.bigRadius : CONFIG.food.baseRadius,
      value: big ? CONFIG.food.bigValue : CONFIG.food.baseValue,
      color: FOOD_COLORS[(Math.random() * FOOD_COLORS.length) | 0],
      kind: 'norm',
      phase: Math.random() * Math.PI * 2,
      vx: 0,
      vy: 0,
    };
  }

  /** Spawn one special power-up at a random spot. */
  spawnPowerup(): void {
    const kinds = CONFIG.powerup.kinds;
    const kind = kinds[(Math.random() * kinds.length) | 0];
    const p = this.randomPos();
    this.items.push({
      id: this.nextId++,
      x: p.x,
      y: p.y,
      r: CONFIG.powerup.radius,
      value: CONFIG.powerup.value,
      color: CONFIG.powerup.colors[kind],
      kind,
      phase: Math.random() * Math.PI * 2,
      vx: 0,
      vy: 0,
    });
    this.dirty = true;
  }

  countPowerups(): number {
    let n = 0;
    for (const it of this.items) if (it.kind !== 'norm') n++;
    return n;
  }

  /** Drop food along a dead worm's body. */
  scatter(positions: Vec[], value: number, color: string): void {
    for (const p of positions) {
      this.items.push({
        id: this.nextId++,
        x: p.x + (Math.random() - 0.5) * 14,
        y: p.y + (Math.random() - 0.5) * 14,
        r: 6.5,
        value,
        color,
        kind: 'norm',
        phase: Math.random() * Math.PI * 2,
        vx: (Math.random() - 0.5) * 90,
        vy: (Math.random() - 0.5) * 90,
      });
    }
    this.dirty = true;
  }

  removeIndices(indices: number[]): void {
    if (indices.length === 0) return;
    indices.sort((a, b) => b - a); // swap-pop from the end
    for (const i of indices) {
      const last = this.items.length - 1;
      this.items[i] = this.items[last];
      this.items.pop();
    }
    this.dirty = true;
  }

  topUp(count: number): void {
    if (this.count >= count) return;
    while (this.count < count) {
      this.items.push(this.makeRandom());
    }
    this.dirty = true;
  }

  // ------------------------------------------------------------------
  // Online mode: the server is authoritative for food.
  // ------------------------------------------------------------------

  /** Replace the whole field with the server's state (on join). */
  setServerItems(list: NetFood[]): void {
    this.items.length = 0;
    for (const f of list) {
      this.items.push(this.fromNet(f));
    }
    this.dirty = true;
  }

  /** Remove food the server says was eaten. Returns the removed items. */
  serverRemove(ids: number[]): FoodItem[] {
    const removed: FoodItem[] = [];
    if (ids.length === 0) return removed;
    const dead = new Set(ids);
    let w = 0;
    for (let i = 0; i < this.items.length; i++) {
      const it = this.items[i];
      if (dead.has(it.id)) {
        removed.push(it);
        continue;
      }
      this.items[w++] = it;
    }
    this.items.length = w;
    this.dirty = true;
    return removed;
  }

  /** Add food the server spawned (death scatter / top-up). */
  serverAdd(list: NetFood[]): void {
    for (const f of list) {
      this.items.push(this.fromNet(f));
    }
    this.dirty = true;
  }

  private fromNet(f: NetFood): FoodItem {
    return {
      id: f.i,
      x: f.x,
      y: f.y,
      r: f.r,
      value: f.v,
      color: f.c,
      kind: kindFromIndex(f.k),
      phase: Math.random() * Math.PI * 2,
      vx: 0,
      vy: 0,
    };
  }

  /** Serialize a subset of items for the network (server-side use). */
  toNet(items: FoodItem[]): NetFood[] {
    return items.map((it) => ({
      i: it.id,
      x: Math.round(it.x),
      y: Math.round(it.y),
      r: it.r,
      v: it.value,
      k: kindIndex(it.kind),
      c: it.color,
    }));
  }

  /** Indices of food within `r` of (x, y). Out array is reused to avoid GC. */
  query(x: number, y: number, r: number, out: number[]): number[] {
    if (this.dirty) this.rebuild();
    out.length = 0;
    const c0x = Math.floor((x - r) / CELL);
    const c1x = Math.floor((x + r) / CELL);
    const c0y = Math.floor((y - r) / CELL);
    const c1y = Math.floor((y + r) / CELL);
    for (let cx = c0x; cx <= c1x; cx++) {
      for (let cy = c0y; cy <= c1y; cy++) {
        const bucket = this.grid.get(cellKey(cx, cy));
        if (!bucket) continue;
        for (const idx of bucket) out.push(idx);
      }
    }
    return out;
  }

  private rebuild(): void {
    this.grid.clear();
    for (let i = 0; i < this.items.length; i++) {
      const it = this.items[i];
      const key = cellKey(Math.floor(it.x / CELL), Math.floor(it.y / CELL));
      const bucket = this.grid.get(key);
      if (bucket) bucket.push(i);
      else this.grid.set(key, [i]);
    }
    this.dirty = false;
  }

  update(dt: number): void {
    // Items move every frame (magnet pull, scatter velocity) — the spatial
    // hash must rebuild on the next query, otherwise moved items become
    // invisible to queries until some other action marks the grid dirty.
    // Rebuilding ~600 entries per frame is negligible.
    this.dirty = true;
    // Decay scatter velocity.
    const k = Math.max(0, 1 - CONFIG.food.scatterDecay * dt);
    for (const it of this.items) {
      if (it.vx !== 0 || it.vy !== 0) {
        it.x += it.vx * dt;
        it.y += it.vy * dt;
        it.vx *= k;
        it.vy *= k;
        if (Math.abs(it.vx) < 1) it.vx = 0;
        if (Math.abs(it.vy) < 1) it.vy = 0;
      }
    }
  }
}
