/**
 * Touch + mouse + keyboard input.
 *
 * Mobile: drag anywhere on the canvas = virtual joystick (direction only).
 * Boost comes ONLY from the dedicated button, a second finger, mouse LMB
 * or Space — never from drag distance, otherwise normal steering would
 * drain score as boost fuel (classic mobile bug).
 * Desktop: mouse steers, hold LMB or Space to boost, WASD/arrows steer.
 */
export interface Joystick {
  active: boolean;
  baseX: number;
  baseY: number;
  curX: number;
  curY: number;
}

const JOY_MAX = 60; // joystick knob travel radius (CSS px) — base slides beyond it
const STEER_DEAD_ZONE = 14;

export class InputController {
  targetAngle = 0;

  joystick: Joystick = { active: false, baseX: 0, baseY: 0, curX: 0, curY: 0 };

  private canvas: HTMLCanvasElement;
  private hasMouse = false;
  private mouseX = 0;
  private mouseY = 0;
  private mouseDown = false;
  private keys = new Set<string>();
  private steerId: number | null = null;
  private boostTouchId: number | null = null;
  private boostButton = false;
  private detach: Array<() => void> = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const rectOf = () => canvas.getBoundingClientRect();

    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === 'mouse') {
        if (e.button === 0) this.mouseDown = true;
        return;
      }
      const rect = rectOf();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      // First free touch steers, a second simultaneous touch boosts.
      if (this.steerId === null) {
        this.steerId = e.pointerId;
        this.joystick.active = true;
        this.joystick.baseX = x;
        this.joystick.baseY = y;
        this.joystick.curX = x;
        this.joystick.curY = y;
      } else if (this.boostTouchId === null) {
        this.boostTouchId = e.pointerId;
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      if (e.pointerType === 'mouse') {
        this.hasMouse = true;
        const rect = rectOf();
        this.mouseX = e.clientX - rect.left;
        this.mouseY = e.clientY - rect.top;
        return;
      }
      if (e.pointerId === this.steerId) {
        const rect = rectOf();
        this.joystick.curX = e.clientX - rect.left;
        this.joystick.curY = e.clientY - rect.top;
      }
    };

    const onPointerUp = (e: PointerEvent) => {
      if (e.pointerType === 'mouse') {
        if (e.button === 0) this.mouseDown = false;
        return;
      }
      if (e.pointerId === this.steerId) {
        this.steerId = null;
        this.joystick.active = false;
      } else if (e.pointerId === this.boostTouchId) {
        this.boostTouchId = null;
      }
    };

    const onKeyDown = (e: KeyboardEvent) => {
      this.keys.add(e.code);
      if (e.code === 'Space') e.preventDefault();
    };
    const onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    const onBlur = () => {
      this.keys.clear();
      this.mouseDown = false;
    };
    const onContextMenu = (e: Event) => e.preventDefault();

    canvas.addEventListener('pointerdown', onPointerDown);
    canvas.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    canvas.addEventListener('contextmenu', onContextMenu);

    this.detach = [
      () => canvas.removeEventListener('pointerdown', onPointerDown),
      () => canvas.removeEventListener('pointermove', onPointerMove),
      () => window.removeEventListener('pointerup', onPointerUp),
      () => window.removeEventListener('pointercancel', onPointerUp),
      () => window.removeEventListener('keydown', onKeyDown),
      () => window.removeEventListener('keyup', onKeyUp),
      () => window.removeEventListener('blur', onBlur),
      () => canvas.removeEventListener('contextmenu', onContextMenu),
    ];
  }

  setBoostButton(v: boolean): void {
    this.boostButton = v;
  }

  /** Called every frame by the engine while the player is alive. */
  update(playerAngle: number): void {
    const boostHeld =
      this.mouseDown ||
      this.boostButton ||
      this.boostTouchId !== null ||
      this.keys.has('Space');

    // 1) Keyboard steering (WASD / arrows).
    let ax = 0;
    let ay = 0;
    if (this.keys.has('ArrowLeft') || this.keys.has('KeyA')) ax -= 1;
    if (this.keys.has('ArrowRight') || this.keys.has('KeyD')) ax += 1;
    if (this.keys.has('ArrowUp') || this.keys.has('KeyW')) ay -= 1;
    if (this.keys.has('ArrowDown') || this.keys.has('KeyS')) ay += 1;
    if (ax !== 0 || ay !== 0) {
      this.targetAngle = Math.atan2(ay, ax);
      this._boosting = boostHeld;
      return;
    }

    // 2) Touch joystick (direction only — no distance-based boost).
    if (this.joystick.active) {
      let dx = this.joystick.curX - this.joystick.baseX;
      let dy = this.joystick.curY - this.joystick.baseY;
      const len = Math.hypot(dx, dy);
      // Slide the base with the thumb so the knob stays under it.
      if (len > JOY_MAX && len > 0) {
        const k = (len - JOY_MAX) / len;
        this.joystick.baseX += dx * k;
        this.joystick.baseY += dy * k;
        dx = this.joystick.curX - this.joystick.baseX;
        dy = this.joystick.curY - this.joystick.baseY;
      }
      if (len > STEER_DEAD_ZONE) {
        this.targetAngle = Math.atan2(dy, dx);
      }
      this._boosting = boostHeld;
      return;
    }

    // 3) Mouse steering (desktop).
    if (this.hasMouse) {
      const w = this.canvas.clientWidth;
      const h = this.canvas.clientHeight;
      const dx = this.mouseX - w / 2;
      const dy = this.mouseY - h / 2;
      if (dx * dx + dy * dy > 8 * 8) {
        this.targetAngle = Math.atan2(dy, dx);
      }
      this._boosting = boostHeld;
      return;
    }

    // 4) Fallback: keep the current heading.
    this.targetAngle = playerAngle;
    this._boosting = boostHeld;
  }

  /** Computed boost flag (read by the engine after update()). */
  get boosting(): boolean {
    return this._boosting;
  }
  private _boosting = false;

  destroy(): void {
    for (const fn of this.detach) fn();
    this.detach.length = 0;
  }
}
