import { io, type Socket } from 'socket.io-client';
import type { NetFood } from './types';

// Flags bitfield for the wire format.
export const FLAG_BOOST = 1;
export const FLAG_MAGNET = 2;
export const FLAG_X2 = 4;
export const FLAG_GHOST = 8;
export const FLAG_FROZEN = 16;
export const FLAG_BOT = 32;

/**
 * Wire state of one worm:
 * [id, x, y, angle, score, flags, name, skinIdx]
 */
export type NetWormState = [number, number, number, number, number, number, string, number];

/** Eaten food entry: [id, x, y] (position for the eat particles). */
export type NetEaten = [number, number, number];

export interface NetHandlers {
  onWelcome(id: number, worms: NetWormState[], food: NetFood[], room: string | null): void;
  onSnapshot(worms: NetWormState[], eaten: NetEaten[]): void;
  onFoodAdd(items: NetFood[]): void;
  onDied(id: number, name: string, score: number): void;
  onRespawned(st: NetWormState): void;
  onFull(): void;
  onBadRoom(): void;
  onStatus(status: 'connecting' | 'connected' | 'error' | 'closed'): void;
}

/**
 * Where the socket.io client connects.
 * - Sandbox/dev default: through the Caddy gateway query param (below).
 * - Production: optionally set NEXT_PUBLIC_NET_URL at build time, e.g.
 *   'wss://ws.example.com'. The bundled Docker + Caddy deploy kit keeps the
 *   same query routing, so the default works there unchanged.
 */
const NET_URL = process.env.NEXT_PUBLIC_NET_URL || '/?XTransformPort=3003';

/**
 * Thin socket.io wrapper for the online arena (mini-service on port 3003,
 * reached through the Caddy gateway with XTransformPort).
 */
export class NetClient {
  private socket: Socket | null = null;
  private h: NetHandlers;
  connected = false;
  /** Invite code of the room we are in (null = global arena). */
  room: string | null = null;

  constructor(handlers: NetHandlers) {
    this.h = handlers;
  }

  connect(name: string, skinIdx: number, room?: string | null): void {
    this.disconnect();
    this.h.onStatus('connecting');
    const socket = io(NET_URL, {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 6,
      reconnectionDelay: 1000,
      timeout: 10000,
    });
    this.socket = socket;

    socket.on('connect', () => {
      this.connected = true;
      const code = (room ?? '').trim().toUpperCase();
      socket.emit('join', {
        name: name.slice(0, 12),
        skin: skinIdx,
        room: code || undefined,
      });
      this.h.onStatus('connected');
    });

    socket.on('welcome', (d: { id: number; room: string | null; worms: NetWormState[]; food: NetFood[] }) => {
      this.room = d.room ?? null;
      this.h.onWelcome(d.id, d.worms, d.food, this.room);
    });

    socket.on('ps', (d: { w: NetWormState[]; e: NetEaten[] }) => {
      this.h.onSnapshot(d.w, d.e);
    });

    socket.on('fa', (d: NetFood[]) => {
      this.h.onFoodAdd(d);
    });

    socket.on('died', (d: { id: number; name: string; score: number }) => {
      this.h.onDied(d.id, d.name, d.score);
    });

    socket.on('respawned', (d: { st: NetWormState }) => {
      this.h.onRespawned(d.st);
    });

    socket.on('full', () => {
      this.h.onFull();
    });

    socket.on('badRoom', () => {
      this.h.onBadRoom();
    });

    socket.on('disconnect', () => {
      this.connected = false;
      this.h.onStatus('closed');
    });

    socket.on('connect_error', () => {
      this.h.onStatus('error');
    });
  }

  sendInput(targetAngle: number, boosting: boolean): void {
    if (!this.socket || !this.connected) return;
    this.socket.emit('st', {
      a: Math.round(targetAngle * 100) / 100,
      b: boosting ? 1 : 0,
    });
  }

  requestRespawn(): void {
    this.socket?.emit('respawn');
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
      this.socket = null;
    }
    this.connected = false;
    this.room = null;
  }
}

export function encodeFlags(w: {
  boosting: boolean;
  magnetT: number;
  x2T: number;
  ghostT: number;
  frozenT: number;
  isPlayer: boolean;
}): number {
  let f = 0;
  if (w.boosting) f |= FLAG_BOOST;
  if (w.magnetT > 0) f |= FLAG_MAGNET;
  if (w.x2T > 0) f |= FLAG_X2;
  if (w.ghostT > 0) f |= FLAG_GHOST;
  if (w.frozenT > 0) f |= FLAG_FROZEN;
  if (!w.isPlayer) f |= FLAG_BOT;
  return f;
}
