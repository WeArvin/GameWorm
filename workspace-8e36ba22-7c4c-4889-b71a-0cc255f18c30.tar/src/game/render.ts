import { BORDER_COLOR, CONFIG, GRID_COLOR, WORLD_BG } from './config';
import type { Game } from './engine';

const FONT_STACK = 'Vazirmatn, "Segoe UI", Tahoma, sans-serif';

function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
): void {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/**
 * Minimal-flat renderer.
 * World pass (camera transform) -> screen pass (minimap, joystick).
 */
export function renderGame(g: Game): void {
  const ctx = g.ctx;
  const w = g.canvas.clientWidth;
  const h = g.canvas.clientHeight;
  if (w === 0 || h === 0) return;

  // Reset to DPR transform set in resize().
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  // Background.
  ctx.fillStyle = WORLD_BG;
  ctx.fillRect(0, 0, w, h);

  const cam = g.cam;
  const scale = cam.scale;

  // Visible world rect (with margin).
  const halfW = w / (2 * scale);
  const halfH = h / (2 * scale);
  const viewL = cam.x - halfW - 40;
  const viewR = cam.x + halfW + 40;
  const viewT = cam.y - halfH - 40;
  const viewB = cam.y + halfH + 40;

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.scale(scale, scale);
  ctx.translate(-cam.x, -cam.y);

  // ---- Grid ------------------------------------------------------------
  const gridStep = 110;
  ctx.strokeStyle = GRID_COLOR;
  ctx.lineWidth = 1 / scale;
  ctx.beginPath();
  for (let gx = Math.floor(Math.max(0, viewL) / gridStep) * gridStep; gx <= Math.min(CONFIG.world.w, viewR); gx += gridStep) {
    ctx.moveTo(gx, Math.max(0, viewT));
    ctx.lineTo(gx, Math.min(CONFIG.world.h, viewB));
  }
  for (let gy = Math.floor(Math.max(0, viewT) / gridStep) * gridStep; gy <= Math.min(CONFIG.world.h, viewB); gy += gridStep) {
    ctx.moveTo(Math.max(0, viewL), gy);
    ctx.lineTo(Math.min(CONFIG.world.w, viewR), gy);
  }
  ctx.stroke();

  // ---- Border ----------------------------------------------------------
  ctx.strokeStyle = BORDER_COLOR;
  ctx.lineWidth = 14;
  roundRectPath(ctx, 0, 0, CONFIG.world.w, CONFIG.world.h, 90);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(229,72,77,0.25)';
  ctx.lineWidth = 34;
  roundRectPath(ctx, 0, 0, CONFIG.world.w, CONFIG.world.h, 90);
  ctx.stroke();

  // ---- Food ------------------------------------------------------------
  for (const it of g.food.items) {
    if (it.x < viewL || it.x > viewR || it.y < viewT || it.y > viewB) continue;
    const bob = Math.sin(g.time * 2.2 + it.phase) * 1.2;
    if (it.kind === 'norm') {
      ctx.fillStyle = it.color;
      ctx.beginPath();
      ctx.arc(it.x, it.y + bob, it.r, 0, Math.PI * 2);
      ctx.fill();
    } else {
      drawPowerup(ctx, g, it.x, it.y + bob, it.r, it.kind, it.color);
    }
  }

  // ---- Worms (player drawn last, on top) --------------------------------
  const worms = g.worms;
  const ordered = worms.filter((wr) => wr.alive);
  ordered.sort((a, b) => (a.isPlayer ? 1 : 0) - (b.isPlayer ? 1 : 0));

  for (const wr of ordered) {
    const n = wr.segX.length;
    if (n === 0) continue;

    // Cheap bounds cull.
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (let s = 0; s < n; s++) {
      const x = wr.segX[s], y = wr.segY[s];
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
    if (maxX < viewL || minX > viewR || maxY < viewT || minY > viewB) continue;

    const r = wr.radius;
    const tailFade = Math.min(5, n - 1);
    const ghost = wr.ghostT > 0;
    if (ghost) ctx.globalAlpha = 0.45;

    // Boost speed streaks behind the head.
    if (wr.boosting) {
      ctx.strokeStyle = 'rgba(255,255,255,0.22)';
      ctx.lineWidth = Math.max(1.5, r * 0.16);
      const bx = -Math.cos(wr.angle);
      const by = -Math.sin(wr.angle);
      const px = -by;
      const py = bx;
      ctx.beginPath();
      for (const side of [-1, 0, 1]) {
        const ox = wr.x + px * r * 0.6 * side;
        const oy = wr.y + py * r * 0.6 * side;
        ctx.moveTo(ox + bx * r * 1.2, oy + by * r * 1.2);
        ctx.lineTo(ox + bx * (r * 2.6 + r * 0.8 * Math.sin(g.time * 30 + side)), oy + by * (r * 2.6 + r * 0.8 * Math.sin(g.time * 30 + side)));
      }
      ctx.stroke();
    }

    for (let s = n - 1; s >= 1; s--) {
      const taper = s > n - 1 - tailFade ? 0.55 + 0.45 * ((n - 1 - s) / tailFade) : 1;
      ctx.fillStyle = s % 2 === 0 ? wr.skin.stripe : wr.skin.base;
      ctx.beginPath();
      ctx.arc(wr.segX[s], wr.segY[s], r * taper, 0, Math.PI * 2);
      ctx.fill();
    }

    // Frozen: icy tint over the body.
    if (wr.frozenT > 0) {
      ctx.fillStyle = 'rgba(124,212,255,0.3)';
      for (let s = n - 1; s >= 1; s -= 1) {
        ctx.beginPath();
        ctx.arc(wr.segX[s], wr.segY[s], r, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Head (slightly bigger than body segments).
    ctx.fillStyle = wr.skin.base;
    ctx.beginPath();
    ctx.arc(wr.x, wr.y, r * CONFIG.worm.headScale, 0, Math.PI * 2);
    ctx.fill();
    if (wr.isPlayer) {
      ctx.strokeStyle = 'rgba(255,255,255,0.85)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.arc(wr.x, wr.y, r * CONFIG.worm.headScale - 1.2, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Effect auras.
    if (wr.magnetT > 0) {
      ctx.strokeStyle = CONFIG.powerup.colors.magnet;
      ctx.lineWidth = 2;
      ctx.setLineDash([7, 7]);
      ctx.lineDashOffset = -g.time * 40;
      ctx.beginPath();
      ctx.arc(wr.x, wr.y, r + 12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    if (wr.x2T > 0) {
      ctx.strokeStyle = CONFIG.powerup.colors.x2;
      ctx.globalAlpha = 0.55 + 0.35 * Math.sin(g.time * 6);
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(wr.x, wr.y, r + 6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = ghost ? 0.45 : 1;
    }

    // Eyes look toward the steering direction.
    const ea = wr.angle;
    const exd = Math.cos(ea);
    const eyd = Math.sin(ea);
    const px = -eyd;
    const py = exd;
    const eyeOff = r * 0.5;
    const eyeFwd = r * 0.45;
    const eyeR = Math.max(2.4, r * 0.34);
    for (const side of [-1, 1]) {
      const ex = wr.x + exd * eyeFwd + px * eyeOff * side;
      const ey = wr.y + eyd * eyeFwd + py * eyeOff * side;
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(ex, ey, eyeR, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#17171C';
      ctx.beginPath();
      ctx.arc(ex + exd * eyeR * 0.35, ey + eyd * eyeR * 0.35, eyeR * 0.52, 0, Math.PI * 2);
      ctx.fill();
    }

    // Name label.
    ctx.fillStyle = wr.isPlayer ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.62)';
    ctx.font = `${wr.isPlayer ? 600 : 500} 13px ${FONT_STACK}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText(wr.name, wr.x, wr.y - r - 8);
    ctx.globalAlpha = 1;
  }

  // ---- Particles --------------------------------------------------------
  for (const p of g.particles) {
    ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  ctx.restore();

  // ---- Screen space: minimap -------------------------------------------
  drawMinimap(g, ctx, w, h);

  // ---- Screen space: joystick ------------------------------------------
  const joy = g.playerInputJoystick;
  if (joy && joy.active) {
    ctx.strokeStyle = 'rgba(255,255,255,0.22)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(joy.baseX, joy.baseY, 52, 0, Math.PI * 2);
    ctx.stroke();
    const dx = joy.curX - joy.baseX;
    const dy = joy.curY - joy.baseY;
    const len = Math.hypot(dx, dy);
    const cl = len > 52 ? 52 / len : 1;
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.beginPath();
    ctx.arc(joy.baseX + dx * cl, joy.baseY + dy * cl, 22, 0, Math.PI * 2);
    ctx.fill();
  }
}

/**
 * Draw a special power-up item: colored disc + pulsing glow + white glyph.
 */
function drawPowerup(
  ctx: CanvasRenderingContext2D,
  g: Game,
  x: number,
  y: number,
  r: number,
  kind: string,
  color: string,
): void {
  const pulse = 1 + Math.sin(g.time * 3 + x * 0.01) * 0.15;

  // Glow ring.
  ctx.globalAlpha = 0.35;
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(x, y, r * pulse + 5, 0, Math.PI * 2);
  ctx.stroke();
  ctx.globalAlpha = 1;

  // Disc.
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();

  // Inner edge for a flat "sticker" look.
  ctx.strokeStyle = 'rgba(0,0,0,0.18)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(x, y, r - 1, 0, Math.PI * 2);
  ctx.stroke();

  // White glyph.
  ctx.strokeStyle = '#FFFFFF';
  ctx.fillStyle = '#FFFFFF';
  ctx.lineWidth = 2.4;
  ctx.lineCap = 'round';
  const s = r * 0.62;
  if (kind === 'magnet') {
    // Horseshoe: bottom half arc + two tip ticks.
    ctx.beginPath();
    ctx.arc(x, y - s * 0.25, s, Math.PI * 0.08, Math.PI * 0.92, false);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x - s, y - s * 0.25);
    ctx.lineTo(x - s, y - s * 0.75);
    ctx.moveTo(x + s, y - s * 0.25);
    ctx.lineTo(x + s, y - s * 0.75);
    ctx.stroke();
  } else if (kind === 'x2') {
    ctx.font = `800 ${Math.round(r * 1.15)}px ${FONT_STACK}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('×2', x, y + 1);
  } else if (kind === 'ghost') {
    // Two cute eyes.
    for (const side of [-1, 1]) {
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(x + side * s * 0.55, y - s * 0.2, s * 0.38, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#2B2B33';
      ctx.beginPath();
      ctx.arc(x + side * s * 0.55, y - s * 0.2, s * 0.18, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (kind === 'freeze') {
    // Snowflake: three crossing lines.
    ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      const a = (i * Math.PI) / 3;
      const dx = Math.cos(a) * s;
      const dy = Math.sin(a) * s;
      ctx.beginPath();
      ctx.moveTo(x - dx, y - dy);
      ctx.lineTo(x + dx, y + dy);
      ctx.stroke();
    }
  }
  ctx.lineCap = 'butt';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
}

function drawMinimap(g: Game, ctx: CanvasRenderingContext2D, w: number, h: number): void {
  const size = Math.min(116, Math.max(84, w * 0.18));
  const margin = 14;
  const x = margin;
  const y = 104; // below the stacked HUD chips
  const sx = size / CONFIG.world.w;
  const sy = size / CONFIG.world.h;

  ctx.fillStyle = 'rgba(23,23,28,0.6)';
  roundRectPath(ctx, x, y, size, size, 10);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.14)';
  ctx.lineWidth = 1;
  roundRectPath(ctx, x, y, size, size, 10);
  ctx.stroke();

  for (const wr of g.worms) {
    if (!wr.alive) continue;
    const px = x + wr.x * sx;
    const py = y + wr.y * sy;
    ctx.fillStyle = wr.isPlayer ? '#FFFFFF' : wr.skin.base;
    ctx.globalAlpha = wr.isPlayer ? 1 : 0.75;
    ctx.beginPath();
    ctx.arc(px, py, wr.isPlayer ? 3.4 : 2.2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}
