import type { Lang } from './types';

export interface SaveData {
  name: string;
  skinIdx: number;
  lang: Lang;
  best: number;
}

const KEY = 'wormArena.v1';

const DEFAULTS: SaveData = {
  name: '',
  skinIdx: 0,
  lang: 'fa',
  best: 0,
};

export function loadSave(): SaveData {
  if (typeof window === 'undefined') return { ...DEFAULTS };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      name: typeof parsed.name === 'string' ? parsed.name : DEFAULTS.name,
      skinIdx: clampInt(parsed.skinIdx, 0, 7),
      lang: parsed.lang === 'en' ? 'en' : 'fa',
      best: typeof parsed.best === 'number' && parsed.best >= 0 ? Math.floor(parsed.best) : 0,
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export function saveSave(data: SaveData): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // storage may be unavailable (private mode) — ignore
  }
}

function clampInt(v: unknown, min: number, max: number): number {
  const n = typeof v === 'number' ? Math.floor(v) : min;
  return Math.max(min, Math.min(max, n));
}
