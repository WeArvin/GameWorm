export interface Vec {
  x: number;
  y: number;
}

/** Flat vibrant skin (base color + darker stripe color). */
export interface Skin {
  base: string;
  stripe: string;
}

export type PowerupKind = 'norm' | 'magnet' | 'x2' | 'ghost' | 'freeze';

export interface FoodItem {
  id: number; // stable id (server-assigned in online mode)
  x: number;
  y: number;
  r: number;
  value: number;
  color: string;
  kind: PowerupKind;
  phase: number; // bob animation phase
  vx: number; // scatter velocity (dropped food)
  vy: number;
}

/** Wire format for food (compact, JSON-safe). */
export interface NetFood {
  i: number; // id
  x: number;
  y: number;
  r: number;
  v: number; // value
  k: number; // kind index: 0 norm, 1 magnet, 2 x2, 3 ghost, 4 freeze
  c: string; // color
}

/** Per-worm flags bitfield (matches net.ts FLAG_* constants). */
export interface WormFlags {
  boosting: boolean;
  magnet: boolean;
  x2: boolean;
  ghost: boolean;
  frozen: boolean;
}

export interface SegEntry {
  wi: number; // worm index in engine.worms
  s: number; // segment index (0 = head)
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  life: number;
  maxLife: number;
  color: string;
}

export interface LeaderEntry {
  name: string;
  score: number;
  isPlayer: boolean;
}

export interface Effects {
  magnet: number; // seconds remaining (0 = inactive)
  x2: number;
  ghost: number;
  frozen: number;
}

export interface Stats {
  score: number;
  length: number;
  rank: number;
  total: number;
  /** Real (human) players in the current online arena/room. */
  players: number;
  leaders: LeaderEntry[];
  effects: Effects;
}

export type Lang = 'fa' | 'en';
export type GameMode = 'demo' | 'play' | 'online';

export interface SteerInput {
  targetAngle: number;
  boosting: boolean;
}
