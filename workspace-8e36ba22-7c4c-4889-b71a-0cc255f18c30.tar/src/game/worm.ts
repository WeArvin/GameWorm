import { CONFIG } from './config';
import type { Skin, SteerInput } from './types';

const PATH_STEP = 3; // world px between stored path points

/**
 * A worm (player, bot or remote networked worm).
 *
 * The head moves and every past head position is pushed into `path`
 * (a flat array of [x0,y0,x1,y1,...], newest first). Body segments are
 * sampled along that path at dynamic spacing — this gives the classic
 * smooth "snake follows head" motion.
 *
 * Worms Zone-style growth: eating makes the worm BOTH longer and
 * thicker (radius grows with sqrt(score), segment spacing grows with
 * the radius so big worms look chunky, not just stretched).
 */
export class Worm {
  id: number;
  name: string;
  skin: Skin;
  isPlayer: boolean;
  alive = true;

  /** Bot brain skill: 0 = dumb (easy prey), 1 = smart. Ignored for players. */
  skill = 1;
  /** Online: head position/angle driven by the network, not local physics. */
  isRemote = false;
  /** Online: remote worm is a server-side bot (not a real player). */
  isBot = false;

  x = 0;
  y = 0;
  angle = 0;
  targetAngle = 0;
  score: number = CONFIG.worm.startScore;
  boosting = false;

  // Power-up timers (seconds remaining, 0 = inactive).
  magnetT = 0;
  x2T = 0;
  ghostT = 0;
  frozenT = 0;

  /** Current smoothed speed (world px/s) — ramps toward the target. */
  speedCur: number = CONFIG.worm.baseSpeed;

  /** Flat path history: [x0, y0, x1, y1, ...] — index 0 is the most recent point. */
  path: number[] = [];
  /** Sampled segment positions (world coords), index 0 = head. */
  segX: number[] = [];
  segY: number[] = [];

  constructor(id: number, name: string, skin: Skin, isPlayer: boolean) {
    this.id = id;
    this.name = name;
    this.skin = skin;
    this.isPlayer = isPlayer;
  }

  get radius(): number {
    return Math.min(
      CONFIG.worm.radiusMax,
      CONFIG.worm.baseRadius + Math.sqrt(Math.max(0, this.score)) * CONFIG.worm.radiusFactor,
    );
  }

  /** Segment spacing grows with girth so big worms are long AND voluminous. */
  get spacing(): number {
    return (
      CONFIG.worm.segSpacing + (this.radius - CONFIG.worm.baseRadius) * CONFIG.worm.spacingPerRadius
    );
  }

  /** Bigger worms turn a bit slower (Worms Zone feel). */
  get turnMul(): number {
    return 1 / (1 + (this.radius - CONFIG.worm.baseRadius) * CONFIG.worm.turnPerRadius);
  }

  get segments(): number {
    return Math.min(
      CONFIG.worm.maxSegments,
      CONFIG.worm.startLength + Math.floor(Math.max(0, this.score) / CONFIG.worm.scorePerSegment),
    );
  }

  reset(x: number, y: number, angle: number, score: number): void {
    this.x = x;
    this.y = y;
    this.angle = angle;
    this.targetAngle = angle;
    this.score = score;
    this.boosting = false;
    this.alive = true;
    this.speedCur = CONFIG.worm.baseSpeed;
    this.magnetT = 0;
    this.x2T = 0;
    this.ghostT = 0;
    this.frozenT = 0;
    this.path.length = 0;
    // Seed the path straight behind the head so the body spawns stretched out.
    const n = this.segments;
    for (let i = n * 2; i >= 1; i--) {
      this.path.push(x - Math.cos(angle) * i * PATH_STEP, y - Math.sin(angle) * i * PATH_STEP);
    }
    this.rebuildSegments();
  }

  update(dt: number, input: SteerInput): void {
    // Sanity: never let a corrupt score poison the whole simulation.
    if (!Number.isFinite(this.score)) this.score = CONFIG.worm.startScore;

    // Tick power-up timers.
    if (this.magnetT > 0) this.magnetT -= dt;
    if (this.x2T > 0) this.x2T -= dt;
    if (this.ghostT > 0) this.ghostT -= dt;
    if (this.frozenT > 0) this.frozenT -= dt;

    // Smooth turn toward the target angle.
    // Slower when: huge (girth), frozen, or a dumb bot (skill 0).
    const skillTurn = this.skill === 0 ? CONFIG.bots.dumb.turnMul : 1;
    const turn =
      CONFIG.worm.turnRate *
      this.turnMul *
      skillTurn *
      (this.frozenT > 0 ? CONFIG.powerup.freezeFactor : 1);
    const maxTurn = turn * dt;
    let da = input.targetAngle - this.angle;
    while (da > Math.PI) da -= Math.PI * 2;
    while (da < -Math.PI) da += Math.PI * 2;
    this.angle += Math.max(-maxTurn, Math.min(maxTurn, da));

    // Boost is free (Worms Zone style) — no score drain, no food drop.
    this.boosting = input.boosting;

    // Speed ramps smoothly toward the target — punchy boost, no snapping.
    const target = this.boosting ? CONFIG.worm.boostSpeed : CONFIG.worm.baseSpeed;
    const k = 1 - Math.exp(-CONFIG.worm.accelK * dt);
    this.speedCur += (target - this.speedCur) * k;
    const speed = this.speedCur * (this.frozenT > 0 ? CONFIG.powerup.freezeFactor : 1);

    this.x += Math.cos(this.angle) * speed * dt;
    this.y += Math.sin(this.angle) * speed * dt;

    this.pushPath();
    this.rebuildSegments();
    this.trimPath();
  }

  /**
   * Online remote worms: the head position comes from the network.
   * Just record it into the path so the body follows smoothly.
   */
  followPath(dt: number): void {
    if (this.magnetT > 0) this.magnetT -= dt;
    if (this.x2T > 0) this.x2T -= dt;
    if (this.ghostT > 0) this.ghostT -= dt;
    if (this.frozenT > 0) this.frozenT -= dt;
    void dt;
    this.pushPath();
    this.rebuildSegments();
    this.trimPath();
  }

  /** Store the current head position into the path history. */
  private pushPath(): void {
    if (this.path.length < 2) {
      this.path.unshift(this.x, this.y);
      return;
    }
    const dx = this.x - this.path[0];
    const dy = this.y - this.path[1];
    if (dx * dx + dy * dy >= PATH_STEP * PATH_STEP) {
      this.path.unshift(this.x, this.y);
    }
  }

  /** Sample segment positions along the path at dynamic spacing. */
  private rebuildSegments(): void {
    const n = this.segments;
    const spacing = this.spacing;
    if (this.segX.length !== n) {
      this.segX.length = n;
      this.segY.length = n;
    }
    this.segX[0] = this.x;
    this.segY[0] = this.y;

    let s = 1;
    let acc = 0; // distance walked from head to current point (lx, ly)
    let lx = this.x;
    let ly = this.y;
    let pi = 0; // index into path flat array

    while (s < n) {
      if (pi + 1 >= this.path.length) {
        // Path exhausted (shouldn't happen once seeded): stack segments on the tail.
        this.segX[s] = lx;
        this.segY[s] = ly;
        s++;
        continue;
      }
      const qx = this.path[pi];
      const qy = this.path[pi + 1];
      const dx = qx - lx;
      const dy = qy - ly;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d < 1e-6) {
        pi += 2;
        continue;
      }
      const target = s * spacing;
      if (acc + d >= target) {
        const t = (target - acc) / d;
        lx += dx * t;
        ly += dy * t;
        this.segX[s] = lx;
        this.segY[s] = ly;
        acc = target;
        s++;
      } else {
        acc += d;
        lx = qx;
        ly = qy;
        pi += 2;
      }
    }
  }

  private trimPath(): void {
    const maxPoints = ((this.segments * this.spacing) / PATH_STEP + 40) * 2;
    // NaN/negative guard: never let a corrupt score blow up the path array.
    if (!Number.isFinite(maxPoints) || maxPoints < 100) return;
    // Array length must be an INTEGER — a float throws RangeError.
    const mp = Math.floor(maxPoints);
    if (this.path.length > mp) {
      this.path.length = mp;
    }
  }
}
