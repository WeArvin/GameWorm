/**
 * Runs once when the Next.js server process starts (nodejs runtime).
 *
 * The authoritative multiplayer server lives in mini-services/worm-server
 * (socket.io, ports 3003 + 3004). Background shells are reaped in this
 * sandbox, so we spawn it as a CHILD of the long-lived Next.js process —
 * and restart it automatically if it ever exits.
 *
 * GET /api/arm-net does the same on demand (used by the game client).
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;

  try {
    const { spawn } = await import('child_process');
    const { existsSync, openSync } = await import('fs');
    const net = await import('net');
    const path = await import('path');

    const cwd = path.join(process.cwd(), 'mini-services', 'worm-server');
    if (!existsSync(path.join(cwd, 'index.ts'))) return;

    const probe = (port: number): Promise<boolean> =>
      new Promise((resolve) => {
        const s = net.default.connect(port, '127.0.0.1');
        s.once('connect', () => {
          s.end();
          resolve(true);
        });
        s.once('error', () => resolve(false));
        s.setTimeout(800, () => {
          s.destroy();
          resolve(false);
        });
      });

    let childRunning = false;
    let attempts = 0;

    const start = async (): Promise<void> => {
      if (childRunning || (await probe(3003))) return;
      childRunning = true;
      attempts += 1;

      const out = openSync(path.join(process.cwd(), 'worm-server.log'), 'a');
      // Production runs without --hot (plain `bun index.ts`).
      const script = process.env.NODE_ENV === 'production' ? 'start' : 'dev';
      const child = spawn('bun', ['run', script], {
        cwd,
        stdio: ['ignore', out, out],
      });

      const startedAt = Date.now();
      child.on('exit', () => {
        childRunning = false;
        // If it died right away the port is likely taken (already running
        // elsewhere) — do NOT spin into an infinite restart loop.
        const ranLongEnough = Date.now() - startedAt > 10_000;
        if (ranLongEnough && attempts < 20) {
          setTimeout(() => void start(), 2000);
        }
      });
      child.on('error', () => {
        childRunning = false;
      });
    };

    void start();
    console.log('[instrumentation] worm-server spawner armed');
  } catch (err) {
    console.error('[instrumentation] failed to arm worm-server spawner:', err);
  }
}
