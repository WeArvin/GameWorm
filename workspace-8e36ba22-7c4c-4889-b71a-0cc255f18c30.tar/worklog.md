# Worklog

---
Task ID: 1
Agent: Main agent (Super Z)
Task: Build a playable web prototype of a Worms Zone .io-style game (Worm Arena) with Next.js + Canvas 2D — bilingual FA/EN, minimal flat art, bot AI, mobile touch controls.

Work Log:
- Initialized fullstack environment (Next.js 16, App Router, Tailwind 4, shadcn/ui).
- Created game engine under src/game/: config.ts (tunables + skins), types.ts, i18n.ts (FA/EN dicts), storage.ts (localStorage save), worm.ts (path-history body segments), food.ts (spatial-hash food field), bot.ts (danger/food/intercept steering + safe spawn), input.ts (virtual joystick + mouse + keyboard), render.ts (minimal flat canvas renderer + minimap), engine.ts (loop, collisions, camera, particles, demo mode).
- Built React UI: src/components/game/WormGame.tsx (menu with name/skin/language/best score, HUD with score chips + leaderboard, boost button, joystick rendering, death screen with new-record detection), wired into src/app/page.tsx; updated layout.tsx metadata/viewport + Vazirmatn font.
- Fixed lint errors (setState-in-effect) by deferring saved-prefs hydration to requestAnimationFrame and moving hint reset into the play handler.
- Fixed logic bugs: worm-index vs worm-id mismatch in bot segment grid, player-death index shift while iterating doomed set, boosting getter assignment.
- Verified with agent-browser: menu renders (FA default), started game, mouse steering + eating works, leaderboard/FA digits correct, death screen + new record works, Play again/Main menu work, EN toggle + persistence works, mobile 390x780 + iPhone touch emulation OK. No console/page errors. Lint: 0 errors.

Stage Summary:
- Deliverable: fully playable web game "Worm Arena / کرم‌آرنا" on / route.
- Key decisions: offline-with-bots (real multiplayer deferred), Canvas 2D without external game engine, spatial hashing for collisions/food, demo mode behind menu.
- Save data key: wormArena.v1 (name, skinIdx, lang, best).

---
Task ID: 2
Agent: Main agent (Super Z)
Task: Fix two user-reported issues: (1) game must be landscape-first on phones, (2) worm constantly boosted without input so score drained and the worm never grew.

Work Log:
- Root-caused boost bug: flick-to-boost triggered when touch drag exceeded 78px, so normal mobile steering = permanent boost drain (11 score/s).
- input.ts: removed distance-based boost entirely; boost now only via dedicated button, second finger, mouse LMB or Space. Added sliding joystick base (knob clamped to 60px radius) so direction control stays comfortable.
- Landscape: play() now requests fullscreen + screen.orientation.lock('landscape') on touch devices (try/catch — iOS Safari ignores it).
- Added engine.setPaused() freezing the whole world; React shows a "rotate your phone" overlay (RotateCw icon + FA/EN text) whenever playing on a touch device in portrait, and unpauses automatically in landscape.
- Hardened touch detection: pointer:coarse OR maxTouchPoints>0 OR ontouchstart OR UA fallback (sandbox device emulation only swaps UA/viewport).
- Updated i18n strings (howToBoost, rotatePrompt).
- Verified with agent-browser: portrait (390x780 + iPhone UA) shows overlay + paused world + boost button; resize to 780x390 resumes instantly; simulated 420px touch drag via dispatched PointerEvents — score grew 10→13 over 4s with zero drain (bug fixed); death screen renders after crash into border.

Stage Summary:
- Both issues fixed and verified. Mobile UX: landscape-first with graceful portrait guidance; growth economy now correct (eat = grow, boost = deliberate spend).

---
Task ID: 3
Agent: Main agent (Super Z)
Task: 4 user requests: (1) special power-up foods, (2) Worms Zone-style thickness growth + dumber bots (70/30 mix), (3) boost must NOT drop food from the tail, (4) real online multiplayer + better worm movement.

Work Log:
- config.ts: radiusMax 26→38, radiusFactor 0.95 (radius = 11 + sqrt(score)*0.95), dynamic segment spacing (9 + (r-11)*0.42) so worms get long AND voluminous; headScale 1.12; boost is FREE (drain 0, no min score) like Worms Zone; powerup config block (magnet/x2/ghost/freeze, 9 max on map, spawn every 6s); bots config with dumb/pro profiles (dangerRadius 135/225, dangerWeight 0.55/1, borderMargin 190/300, turnMul 0.62/1, attack on/off) + dumbRatio 0.7.
- worm.ts: girth + spacing getters, size-scaled turn rate, smooth speed ramp (accelK 8), power-up timers (magnetT/x2T/ghostT/frozenT), skill-based turn penalty for dumb bots, followPath() for networked worms, score NaN guard.
- CRITICAL BUG FIX: trimPath assigned a FLOAT to array.length → RangeError killed every rAF loop (dynamic spacing broke the old integer math). Fixed with Math.floor + isFinite guard; added try/catch around the server tick so one bad frame can't kill broadcasts.
- CRITICAL BUG FIX: FoodField spatial hash went stale when items moved (magnet pull) — invisible-to-queries food. Now rebuilds each frame (dirty=true in update(); ~600 entries, negligible).
- bot.ts: two skill tiers; dumb bots zone out periodically (sin-based sleep windows), never attack, weakly avoid walls/bodies; pro bots keep intercept attacks and value power-ups 4x.
- engine.ts: boost drops NO food (visual particle streaks only); power-up eating + effects (magnet=330px pull 9s, x2=double 10s, ghost=phase through bodies + invulnerable 7s, freeze=slows others within 520px to 45% for 5s); ghost skip in collisions + bot danger scan; online mode with local prediction, soft reconciliation (snap >260px, lerp 0.08), remote-worm interpolation at 10Hz, input upload at 12.5Hz; emitStats now includes effect timers.
- render.ts: power-up discs with pulsing glow + white glyphs (horseshoe magnet, ×2 text, ghost eyes, snowflake), magnet dashed ring, x2 pulse ring, ghost 45% alpha, frozen icy tint, boost speed streaks, bigger head.
- MULTIPLAYER: mini-services/worm-server (socket.io, path '/', port 3003 + count endpoint on 3004) running the SAME shared sim code (imports src/game/config|worm|food|bot|net) as an authoritative 15Hz server: 10 bots with skill mix, max 12 players, join/st/respawn/disconnect, snapshots [id,x,y,ang,score,flags,name,skin], eaten [id,x,y] triples, food deltas via lastId tracking, deaths broadcast. Client: src/game/net.ts NetClient (io('/?XTransformPort=3003')), flags bitfield. Server validated: 60 ps events in 4s.
- WormGame.tsx + i18n: mode tabs (single/online), live online counter via /count?XTransformPort=3004, connecting overlay, conn-lost/server-full errors, effect chips HUD (Magnet/Gem/Ghost/Snowflake icons + seconds), Home exit button in HUD, online respawn flow (respawned event).
- Fixed: /count was swallowed by socket.io's path '/' → moved to dedicated port 3004.
- E2E via agent-browser: eat→score+radius+spacing all grow; boost 3s = zero drain (speed 330); magnet/x2/freeze timers verified (x2 doubles: 1→2); fat worm at score 500 (radius 32, 182 segs, 3262px); bots 9 dumb/5 pro; online: join via Caddy (localhost:81), 11 remotes ALL moving, ate to score 18, died at border, respawned; iPhone emulation portrait shows rotate overlay + boost button, landscape resumes instantly. Lint 0 errors.

Stage Summary:
- Game now matches Worms Zone core feel: chunky growth, free boost without tail drop, power-ups, easy-but-not-empty bot difficulty.
- Real multiplayer shipped: authoritative bun mini-service + predicted client; fake-player + probe scripts in scripts/ for testing (bun scripts/fake-player.mts "name" seconds).
- Server must keep running: mini-services/worm-server (bun run dev, ports 3003+3004).

---
Task ID: 4
Agent: Main agent (Super Z)
Task: User asked "how can I play with a friend I invite, on one map?" — implement private invite-code rooms on top of the existing global online arena.

Work Log:
- Refactored mini-services/worm-server/index.ts into a Room class: global public arena (code=null, 10 bots) + private rooms (4-char invite code, 4 bots, max 12 players each, max 60 rooms). Per-room worms/food/nextId/timers; room-scoped broadcasts via io.to(key); idle private rooms pause their sim and are GC'd 90s after going empty; /count?room=CODE counts a room (invalid code → 0), /count = global.
- Join protocol: join {name, skin, room?} — valid 4-char code ([A-Z0-9], no 0/O/1/I) joins-or-creates a private room; malformed code now REJECTED via 'badRoom' event instead of silently dumping the player into the global arena.
- Client net.ts: connect(name, skin, room?) sends room; welcome carries room back; onBadRoom handler; NetClient.room field.
- engine.ts: startOnline(name, skin, room?) + roomCode getter; applyFlags stores FLAG_BOT → Worm.isBot; Stats.players = real humans online (self + remote non-bot worms).
- WormGame.tsx: online tab now has a "private room with a friend" box (4-char code input + Join + Create-new-room); room chip in HUD (code + real-player count + copy-invite button + toast); "waiting for your friend" hint while players<2; ?room=CODE URL param pre-fills + banners "invited to room"; invite link = origin/?room=CODE; playAgain/respawn keeps you in the same room; badCode net error shown bilingually.
- INFRA FIX (critical): sandbox reaps background shells, so `bun run dev` for the mini-service died between tool calls. Fixed with src/instrumentation.ts (arms the spawner when Next starts) + GET /api/arm-net (probes 3003, spawns mini-service as a CHILD of the long-lived next-server, safe to call repeatedly). Client calls /api/arm-net right before any online join → self-healing for end users.
- Type fixes surfaced by tsc: Worm.score/speedCur now annotated :number (as-const CONFIG made them literal types), Skin interface added to types.ts, i18n dict as-const removed (Dict widened), Worm.isBot field.
- Testing: fake-player.mts extended with a room arg. Verified: create X7K2 → welcome room=X7K2 (5 worms: host+4 bots); friend joins same code → 6 worms, room count 2, global 0; TOOLONG code → badRoom rejected; browser E2E via Caddy (:81): create room → HUD chip "اتاق: 57B3 · ۱ بازیکن واقعی" + waiting hint; fake friend joins same code → chip flips to "۲ بازیکن واقعی", rank x/6; invite link ?room=57B3 in new tab auto-fills code → Join lands in the same room (3 in room); die → respawn stays in room; menu→online→global join works; offline single mode regression OK (score grows, zero console errors). Lint 0 errors, tsc 0 src errors.

Stage Summary:
- ANSWER to user: share the room code OR the invite link — both land on the same private map (you + friend + 4 bots). Global arena (no code) unchanged.
- Key decision: kept the authoritative bun mini-service (socket.io, 3003/3004) but made it multi-room; service is now supervised by the Next.js process (instrumentation + /api/arm-net) because plain background processes get reaped in this sandbox.
- NOTE: testing must go through the Caddy gateway (port 81 / preview URL), NOT localhost:3000 — only Caddy routes XTransformPort.

---
Task ID: 5
Agent: Main agent (Super Z)
Task: User reported death-screen typo ("باخردی" should be "باختی") and asked how to publish the game publicly (final version).

Work Log:
- Fixed youDied typo in src/game/i18n.ts (باخردی → باختی); confirmed in source and in the production bundle.
- Production-enabling tweaks: net.ts NET_URL honors optional NEXT_PUBLIC_NET_URL build-time env (default unchanged '/?XTransformPort=3003'); worm-server package.json gained "start": "bun index.ts"; instrumentation.ts + /api/arm-net now spawn 'start' vs 'dev' based on NODE_ENV.
- Deployment kit: Dockerfile (2-stage oven/bun:1 — standalone Next + src/game + mini-services/worm-server with deps in one image, CMD bun server.js), docker-compose.yml (app + caddy:2 auto-HTTPS via DOMAIN env), deploy/Caddyfile.prod (XTransformPort 3003/3004 routing, default→app:3000), deploy/.env.example, .dockerignore.
- DEPLOY.md: Persian step-by-step publishing guide (3 paths: VPS+Docker recommended / Vercel single-player-only / Iranian PaaS; Docker install, git or zip upload, DNS A record, compose up, update flow, FAQ: 12 players/room × 60 rooms, localStorage scores, no DB).
- Verified: bun lint 0 errors; bun run build OK; standalone :3100 curl checks (200, /api/arm-net running, socket.io handshake via gateway, /count OK); FULL production-composition browser E2E with a temporary user-level Caddy on :3200 (sandbox blocks low ports): styled menu → online tab → join → HUD score 12, length 20, rank 10/10, live leaderboard — zero page errors (screenshots .zscripts/prod_menu_styled.png, prod_online_hud.png). Dev server + worm-server untouched and healthy after tests.

Stage Summary:
- Typo fixed; game is deployment-ready: public launch is one command (docker compose up -d --build) on any VPS; DEPLOY.md (Persian) is the manual.
- Key decision: kept the query-param routing in production (same Caddy pattern as sandbox) → zero protocol changes; NEXT_PUBLIC_NET_URL is the escape hatch for split deployments.
- Test tooling persisted: scripts/prod-smoke.sh, scripts/prod-e2e.sh (self-cleaning; bind ports ≥3000 in this sandbox).
